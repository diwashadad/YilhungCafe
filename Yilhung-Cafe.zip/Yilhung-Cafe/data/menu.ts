/**
 * MENU DATA
 * Source: customer-uploaded Google Maps photos of the café's PRINTED MENU (Aug 2026 colour menu and an
 * older Jun 2026 white menu), supplied by the agency owner as screenshots on 2026-11-10.
 * Item NAMES are transcribed from those photos. The photos themselves are not reused.
 *
 * `price` = a price legible and consistent in the most recent menu photo. Everything else is null
 * ("to be confirmed"): drink prices were blurry, or the Aug and Jun menus disagree (e.g. boba milk tea
 * M $5.50 in Jun vs ~$5.99 in Aug). Confirm with the café before publishing.
 * `demoPrice` powers the Online Ordering Demo ONLY. It equals the verified price when one exists,
 * otherwise it is a placeholder.
 */
export type Option = { id: string; label: string; extra?: number };
export type OptionGroup = { id: string; label: string; options: Option[]; required?: boolean };
export type MenuItem = {
  id: string; name: string; category: string; description: string;
  price: number | null;
  sizes?: { m: number; l: number };      // verified medium/large prices, when legible
  flavors?: string[];                    // flavor options listed on the printed menu
  demoPrice: number; signature?: boolean; tags?: string[]; groups?: OptionGroup[];
  art: "butter-tea" | "boba" | "latte" | "iced" | "fruit" | "lassi" | "slushy" | "chatpat" | "liangfen" | "momo";
};

export const MENU_SOURCE_NOTE = "Item names from the café’s printed menu (via customer Google Maps photos). Prices are shown only where legible; others are to be confirmed.";

const size: OptionGroup = { id: "size", label: "Size (demo)", required: true, options: [{ id: "reg", label: "Medium" }, { id: "lg", label: "Large", extra: 1 }] };
const temp: OptionGroup = { id: "temp", label: "Temperature (demo)", required: true, options: [{ id: "hot", label: "Hot" }, { id: "iced", label: "Iced" }] };
const sweet: OptionGroup = { id: "sweet", label: "Sweetness (demo)", required: true, options: [{ id: "s0", label: "Less sweet" }, { id: "s1", label: "Regular" }, { id: "s2", label: "Extra sweet" }] };
const boba: OptionGroup = { id: "boba", label: "Add-on (demo)", options: [{ id: "none", label: "None" }, { id: "boba", label: "Boba pearls", extra: 0.75 }] };
const spice: OptionGroup = { id: "spice", label: "Spice level (demo)", required: true, options: [{ id: "mild", label: "Mild" }, { id: "med", label: "Medium" }, { id: "hot", label: "Hot" }] };
const flavor = (flavors: string[]): OptionGroup => ({ id: "flavor", label: "Flavor", required: true, options: flavors.map((f) => ({ id: f.toLowerCase().replace(/\W+/g, "-"), label: f })) });

export const categories = ["Teas & Other Drinks", "Boba, Fruit & Café Drinks", "Food & Snacks"] as const;
/** Categories rendered as a compact printed-menu style list instead of cards. */
export const listCategories: string[] = ["Teas & Other Drinks"];

const BOBA = ["Boba", "Rose", "Taro", "Thai", "Chocolate"];
const FRUIT = ["Strawberry", "Rose", "Green Apple", "Mango", "Lychee", "Passion Fruit", "Peach"];
const LASSI = ["Plain", "Strawberry", "Mango", "Banana", "Rose"];
const SLUSHY = ["Mango", "Rose", "Strawberry", "Lychee", "Green Apple"];
const YOGURT = ["Rose", "Strawberry", "Green Apple", "Lychee", "Peach", "Mango"];
const HOT = ["Americano", "Latte", "Espresso", "Cappuccino", "Hot Coffee"];
const ICED = ["Ice Americano", "Ice Latte", "Ice Cappuccino", "Ice Espresso", "Iced Coffee"];

const other = (id: string, name: string, demoPrice: number, extra: Partial<MenuItem> = {}): MenuItem =>
  ({ id, name, category: "Teas & Other Drinks", description: "", price: null, demoPrice, art: "butter-tea", ...extra });

export const menu: MenuItem[] = [
  other("butter-tea", "Himalayan Butter Tea", 5.5, { description: "A traditional Himalayan tea, served salty and rich.", signature: true, tags: ["Signature", "Salty & rich"], groups: [size] }),
  other("milk-tea", "Milk Tea", 4.5, { description: "Milk tea." }),
  other("ginger-honey-lemon", "Ginger Honey Lemon Tea", 5.5),
  other("green-tea", "Green Tea", 4),
  other("black-tea", "Black Tea", 4),
  other("peach-tea", "Peach Tea", 4.5),
  other("apple-cider-chai", "Apple Cider Chai", 5.5),
  other("matcha-latte", "Matcha Latte", 6),
  other("brown-sugar-latte", "Brown Sugar Latte", 6),
  other("jasmine-pot", "Jasmine Tea Pot", 9),

  { id: "boba-milk-tea", name: "Boba Milk Tea", category: "Boba, Fruit & Café Drinks", art: "boba", signature: true, tags: ["Signature", "5 flavors"],
    description: "Milk tea with chewy tapioca pearls, in five flavors.", price: null, flavors: BOBA, demoPrice: 6, groups: [flavor(BOBA), size, sweet, boba] },
  { id: "fruit-tea", name: "Fruit Tea", category: "Boba, Fruit & Café Drinks", art: "fruit", signature: true, tags: ["Signature", "7 flavors", "Fruity"],
    description: "Bright fruit teas, including passion fruit.", price: null, flavors: FRUIT, demoPrice: 6.5, groups: [flavor(FRUIT), size, sweet] },
  { id: "lassi", name: "Lassi", category: "Boba, Fruit & Café Drinks", art: "lassi", tags: ["5 flavors"], description: "Chilled, creamy yogurt drink.",
    price: 4.99, sizes: { m: 4.99, l: 5.99 }, flavors: LASSI, demoPrice: 4.99, groups: [flavor(LASSI), size] },
  { id: "slushy", name: "Slushy", category: "Boba, Fruit & Café Drinks", art: "slushy", tags: ["5 flavors", "Icy"], description: "Icy fruit slushies.",
    price: null, flavors: SLUSHY, demoPrice: 6, groups: [flavor(SLUSHY), size] },
  { id: "yogurt", name: "Yogurt Drink", category: "Boba, Fruit & Café Drinks", art: "lassi", tags: ["6 flavors"], description: "Fruity yogurt drinks.",
    price: null, flavors: YOGURT, demoPrice: 5.5, groups: [flavor(YOGURT), size] },
  { id: "hot-coffee", name: "Hot Coffee", category: "Boba, Fruit & Café Drinks", art: "latte", tags: ["Espresso"], description: "Americano, latte, espresso, cappuccino and more.",
    price: null, flavors: HOT, demoPrice: 5, groups: [flavor(HOT)] },
  { id: "iced-coffee", name: "Iced Coffee", category: "Boba, Fruit & Café Drinks", art: "iced", tags: ["Iced"], description: "Iced americano, latte, cappuccino, espresso and iced coffee.",
    price: null, flavors: ICED, demoPrice: 5.5, groups: [flavor(ICED)] },

  { id: "chatpat", name: "Chatpate", category: "Food & Snacks", art: "chatpat", signature: true, tags: ["Signature", "Street snack", "Tangy"],
    description: "A tangy, savory South Asian street-style snack.", price: 7.99, demoPrice: 7.99, groups: [spice] },
  { id: "momo-beef", name: "Beef Momo", category: "Food & Snacks", art: "momo", tags: ["Dumplings"], description: "Dumplings filled with beef.", price: 9.99, demoPrice: 9.99, groups: [spice] },
  { id: "momo-veg", name: "Veg. Momo", category: "Food & Snacks", art: "momo", tags: ["Dumplings", "Vegetarian"], description: "Dumplings filled with vegetables.", price: 8.99, demoPrice: 8.99, groups: [spice] },
  { id: "laphing", name: "Laphing", category: "Food & Snacks", art: "liangfen", tags: ["Cold noodles"], description: "A noodle dish from the café’s snack menu.", price: 7.99, demoPrice: 7.99, groups: [spice] },
  { id: "spicy-reman", name: "Spicy Reman", category: "Food & Snacks", art: "chatpat", tags: ["Spicy"], description: "A spicy noodle dish.", price: 7.99, demoPrice: 7.99, groups: [spice] },
  { id: "ramen-beef", name: "Beef Ramen", category: "Food & Snacks", art: "liangfen", tags: ["Noodle soup"], description: "Ramen with beef.", price: 7.99, demoPrice: 7.99 },
  { id: "ramen-egg", name: "Egg Ramen", category: "Food & Snacks", art: "liangfen", tags: ["Noodle soup"], description: "Ramen with egg.", price: 6.99, demoPrice: 6.99 },
  { id: "spicy-potato", name: "Spicy Potato", category: "Food & Snacks", art: "chatpat", tags: ["Spicy"], description: "A spicy potato dish.", price: 7.99, demoPrice: 7.99, groups: [spice] },
  { id: "liangfen", name: "Liangfen", category: "Food & Snacks", art: "liangfen", tags: ["Street snack", "Cold"],
    description: "A chilled jelly-noodle snack, dressed and served cold.", price: null, demoPrice: 8, groups: [spice] },
];
