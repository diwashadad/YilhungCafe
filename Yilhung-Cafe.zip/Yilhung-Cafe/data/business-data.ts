/**
 * Verified business data for Yilhung Cafe.
 * RULE: nothing here is invented. Anything not verified is `null` and the UI shows
 * "to be confirmed". Every verified field lists its source.
 * Research log (session date 2026-11-10): the research environment could not reach
 * Google Maps, Instagram, Yelp or listing sites (network-restricted), so hours,
 * phone, prices and photos are UNVERIFIED and must be supplied by the agency owner.
 */
export type Verified<T> = { value: T; sources: string[] };

export const MAPS_URL =
  "https://www.google.com/maps/search/?api=1&query=Yilhung+Cafe+40-36+75th+St+Elmhurst+NY";
export const MAPS_EMBED_URL =
  "https://www.google.com/maps?q=Yilhung+Cafe+40-36+75th+St+Elmhurst+NY&output=embed";
export const DIRECTIONS_URL =
  "https://www.google.com/maps/dir/?api=1&destination=Yilhung+Cafe+40-36+75th+St+Elmhurst+NY";

export const business = {
  name: { value: "Yilhung Cafe", sources: ["Agency brief (owner-provided)"] } as Verified<string>,
  address: {
    value: { street: "40-36 75th St", city: "Elmhurst", state: "NY", zip: "11373", display: "40-36 75th St, Elmhurst, NY 11373" },
    sources: ["Agency brief (owner-provided)", "https://www.atly.com/location/YilhungCafe (search listing)"],
  } as Verified<{ street: string; city: string; state: string; zip: string; display: string }>,
  mapsUrl: { value: MAPS_URL, sources: ["Agency brief (owner-provided)"] } as Verified<string>,
  /** Offerings named in the brief and corroborated by the Karpo listing snippet. */
  offerings: {
    value: ["Himalayan butter tea", "Boba milk tea", "Lattes", "Passion fruit refreshers", "Chatpat", "Liangfen"],
    sources: ["Agency brief (owner-provided)", "https://app.karpo.ai/explore/experience/yilhung-cafe (search snippet)"],
  } as Verified<string[]>,
  features: {
    value: ["Himalayan crafts", "A welcoming interior", "A corner dedicated to Himalayan artifacts and crafts", "A warm, stylish atmosphere"],
    sources: ["Agency brief (owner-provided)", "https://www.atly.com/location/YilhungCafe (search snippet, 2nd research pass; re-verify)"],
  } as Verified<string[]>,
  /** Neighborhood naming differs by source (Atly: Elmhurst; Karpo: Jackson Heights). Site uses the postal address as given. */
  neighborhoodNote: { value: "Listed as Elmhurst (Atly) and as Jackson Heights (Karpo)", sources: ["https://www.atly.com/location/YilhungCafe", "https://app.karpo.ai/explore/experience/yilhung-cafe"] } as Verified<string>,
  /** Ratings differ between sources (4.8 vs 6.7), so NO rating is displayed anywhere. */
  /** Karpo snippet describes butter tea as "salty, rich". */
  butterTeaNote: { value: "salty, rich butter tea", sources: ["https://app.karpo.ai/explore/experience/yilhung-cafe (search snippet)"] } as Verified<string>,
  payments: {
    value: "Credit cards accepted; cash preferred for smaller purchases.",
    sources: ["https://www.atly.com/location/YilhungCafe (search snippet; re-verify before publishing)"],
  } as Verified<string>,
  // ---- NOT VERIFIED — supply from Google Business Profile / owner ----
  hours: null as Verified<{ day: string; open: string }[]> | null,
  /** Read from the printed-menu footer in a customer Google Maps photo (Aug 2026); confirm the digits with a call. */
  phone: { value: "(929) 608-4791", sources: ["Customer-uploaded Google Maps photo of the printed menu footer (agency-supplied screenshot, 2026-11-10); confirm before publishing"] } as Verified<string> | null,
  website: null as Verified<string> | null,
  instagram: null as Verified<string> | null,
  email: null as Verified<string> | null,
} as const;

export const UNVERIFIED_NOTE = "To be confirmed — see Google Maps for current details.";

export const disclaimer = "Unofficial redesign concept — not affiliated with Yilhung Cafe.";
