# Yilhung Cafe: unofficial redesign concept (demo)

> Unofficial redesign concept — not affiliated with Yilhung Cafe.

Next.js 16 (static export) · React 19 · TypeScript · Tailwind v4 · shadcn/ui-style components · Lucide · Motion · Cloudflare Workers (static assets + one tiny contact endpoint).
Imagery is original in-house illustration, labeled "Illustration"; real photos are not used until authorized.

## Save location
Keep this folder at `Desktop/Website/Yilhung-Cafe/` (one folder per business; never mix projects).

## Run locally
```bash
npm install
npm run dev        # fast UI work at http://localhost:3000 (contact form needs the Worker, see next line)
npm run preview    # builds and serves exactly like Cloudflare at http://localhost:8787 (use this to test the contact form)
```

## Tests
```bash
npm run lint && npm test                      # types (site + worker) and unit tests
npm run build && npx wrangler dev --port 8787 &    # then:
BASE=http://127.0.0.1:8787 CHROMIUM=/path/to/chromium node tests/e2e.mjs
```
(E2E covers navigation, menu search/filters, cart, contact form, mobile menu, horizontal overflow and console errors.)

## Pages
`/` Home · `/menu` · `/story` · `/gallery` · `/visit` (map, directions) · `/contact` · `/order` (demo cart; no real orders or payments).

## Data and honesty rules
`data/business-data.ts` and `data/menu.ts` hold verified facts with sources; unverified fields render "to be confirmed". See `docs/VERIFICATION.md` and `docs/IMAGE-SOURCES.md`.

## Docs
- `docs/GITHUB.md`: push to a private repo
- `docs/CLOUDFLARE.md`: deploy, rollback, analytics, domain
- `docs/HANDOVER.md`: client ownership transfer and future updates
- `docs/SALES-KIT.md`: pitch, email, pricing

The demo ships `noindex` (`public/_headers`, meta, robots.txt). Nothing is deployed. Do not remove the disclaimer or noindex without the café's written approval.
