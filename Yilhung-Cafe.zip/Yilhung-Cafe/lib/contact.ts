export type ContactInput = { name: string; email: string; message: string; website?: string };
export function validateContact(b: unknown): { ok: true; data: ContactInput } | { ok: false; errors: Record<string, string> } {
  const o = (b && typeof b === "object" ? b : {}) as Record<string, unknown>;
  const s = (k: string) => (typeof o[k] === "string" ? (o[k] as string).trim() : "");
  const data = { name: s("name"), email: s("email"), message: s("message"), website: s("website") };
  const errors: Record<string, string> = {};
  if (data.name.length < 2 || data.name.length > 100) errors.name = "Please enter your name.";
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(data.email) || data.email.length > 200) errors.email = "Please enter a valid email address.";
  if (data.message.length < 10) errors.message = "Please write at least 10 characters.";
  if (data.message.length > 4000) errors.message = "Message is too long (4000 characters max).";
  return Object.keys(errors).length ? { ok: false, errors } : { ok: true, data };
}
