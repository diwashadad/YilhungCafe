"use client";
import * as React from "react";
import { menu, type MenuItem } from "@/data/menu";

export type CartLine = { key: string; itemId: string; choices: Record<string, string>; qty: number; note?: string };
type Ctx = {
  lines: CartLine[]; add: (itemId: string, choices: Record<string, string>, qty?: number, note?: string) => void;
  setQty: (key: string, qty: number) => void; remove: (key: string) => void; clear: () => void;
  count: number; subtotal: number; unitPrice: (l: CartLine) => number; item: (id: string) => MenuItem;
};
const CartCtx = React.createContext<Ctx | null>(null);
const KEY = "yilhung-demo-cart-v1";

export const itemById = (id: string) => menu.find((m) => m.id === id)!;
export function unitPriceOf(l: { itemId: string; choices: Record<string, string> }) {
  const it = itemById(l.itemId);
  const extra = (it.groups ?? []).reduce((s, g) => s + (g.options.find((o) => o.id === l.choices[g.id])?.extra ?? 0), 0);
  return it.demoPrice + extra;
}
export const lineKey = (itemId: string, choices: Record<string, string>, note?: string) =>
  [itemId, ...Object.entries(choices).sort().map(([k, v]) => `${k}:${v}`), note ?? ""].join("|");

export function CartProvider({ children }: { children: React.ReactNode }) {
  const [lines, setLines] = React.useState<CartLine[]>([]);
  const [ready, setReady] = React.useState(false);
  React.useEffect(() => {
    try { const raw = localStorage.getItem(KEY); if (raw) setLines(JSON.parse(raw)); } catch {}
    setReady(true);
  }, []);
  React.useEffect(() => { if (ready) try { localStorage.setItem(KEY, JSON.stringify(lines)); } catch {} }, [lines, ready]);

  const value = React.useMemo<Ctx>(() => ({
    lines,
    add: (itemId, choices, qty = 1, note) => setLines((cur) => {
      const key = lineKey(itemId, choices, note);
      const found = cur.find((l) => l.key === key);
      return found ? cur.map((l) => (l.key === key ? { ...l, qty: Math.min(20, l.qty + qty) } : l)) : [...cur, { key, itemId, choices, qty, note }];
    }),
    setQty: (key, qty) => setLines((cur) => (qty <= 0 ? cur.filter((l) => l.key !== key) : cur.map((l) => (l.key === key ? { ...l, qty: Math.min(20, qty) } : l)))),
    remove: (key) => setLines((cur) => cur.filter((l) => l.key !== key)),
    clear: () => setLines([]),
    count: lines.reduce((s, l) => s + l.qty, 0),
    subtotal: lines.reduce((s, l) => s + unitPriceOf(l) * l.qty, 0),
    unitPrice: unitPriceOf, item: itemById,
  }), [lines]);
  return <CartCtx.Provider value={value}>{children}</CartCtx.Provider>;
}
export function useCart() { const c = React.useContext(CartCtx); if (!c) throw new Error("useCart outside CartProvider"); return c; }
export const money = (n: number) => `$${n.toFixed(2)}`;
export const TAX_RATE = 0.08875; // NYC combined sales tax — demo calculation only
