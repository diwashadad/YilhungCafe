# Push to your existing GitHub account (private repo)

The sandbox's GitHub token was invalid, so this could not be done from here. The project already has a local git repo
with commits. On **your computer**, from the project folder:

```bash
cd ~/Desktop/Website/Yilhung-Cafe
git status                      # should be clean
gh auth login                   # log in with your EXISTING account (skip if already logged in)
gh repo create Yilhung-Cafe --private --source=. --remote=origin --push
gh repo view --web              # confirm the files are there
```
No GitHub CLI? Create an empty **private** repo named `Yilhung-Cafe` on github.com (no README), then:
```bash
git remote add origin https://github.com/<your-username>/Yilhung-Cafe.git
git branch -M main
git push -u origin main
```
Secrets: `.gitignore` already excludes `.env*.local`, `node_modules`, `.next`, `out`, `.wrangler`. Never commit API keys.
