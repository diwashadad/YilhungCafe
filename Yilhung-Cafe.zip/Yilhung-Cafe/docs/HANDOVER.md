# Handover and future updates

I could not confirm a supported "transfer this Worker/Pages project to another account" feature (docs unreachable from the build
environment). **Plan on redeploying under the client's account**. It's quick because the project is just a GitHub repo.

## After the client pays
1. **GitHub**: repo → Settings → Danger Zone → **Transfer ownership** to the client's GitHub username (they accept by email). Or add them as an admin and later transfer. Secrets are never in the repo (`.env*.local` is git-ignored).
2. **Cloudflare**: client creates (or uses) their own Cloudflare account. In their dashboard: **Workers & Pages → Import a repository** → the transferred repo (same build/deploy commands as `docs/CLOUDFLARE.md`). Re-add any Variables and Secrets (contact destination). Rename `name` in `wrangler.jsonc` if they prefer.
3. **Domain**: client owns the registration. Move the custom domain from your Worker to theirs (remove it from yours first, then add it on theirs).
4. **Verify** the live domain, HTTPS, contact form, and analytics under their account.
5. **Remove yourself**: delete your Worker, remove your access from their GitHub repo and Cloudflare account, unless they agree to keep you as a maintainer.
6. Give them: the repo link, a login walkthrough, and the cost note (domain renewal yearly; hosting free or low-cost per Cloudflare's current plans).

## Keeping limited access (with the client's permission)
GitHub: they stay **owner**, add you as a **collaborator**. Cloudflare: they invite you as a **member** with a restricted role. They can revoke it any time.

## Future updates (beginner steps)
```bash
cd ~/Desktop/Website/Yilhung-Cafe
claude                      # open Claude Code in this folder, describe the change ("update the hours", "change a price")
npm run preview             # check it at http://localhost:8787
git add -A && git commit -m "Update hours"
git push                    # Cloudflare redeploys automatically
```
Where things live: text and pages in `app/`, menu and prices in `data/menu.ts`, hours/phone/address in `data/business-data.ts`, photos go in `public/images/` (then see `docs/IMAGE-SOURCES.md`).
Mistake live? Cloudflare dashboard → Worker → Deployments → roll back, or `git revert HEAD && git push`.
