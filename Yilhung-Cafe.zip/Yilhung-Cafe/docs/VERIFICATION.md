# Verification status (as of 2026-11-10)

| Fact | Status | Source |
|---|---|---|
| Name: Yilhung Cafe | Verified (brief) | Agency brief |
| Address: 40-36 75th St, Elmhurst, NY 11373 | Verified | Brief + Atly listing snippet |
| Offerings: Himalayan butter tea, boba milk tea, lattes, passion fruit refreshers, chatpat, liangfen | Verified | Brief + Karpo snippet |
| Himalayan crafts, welcoming interior | From brief only | Agency brief |
| Butter tea "salty, rich" | Karpo snippet | app.karpo.ai (re-verify) |
| Cards accepted / cash preferred | Atly snippet | re-verify before publishing |
| A corner dedicated to Himalayan artifacts and crafts; warm, stylish atmosphere | Single listing snippet | atly.com (2nd pass; re-verify) |
| Ratings (4.8 on Karpo vs 6.7 on Atly) | Conflicting, so NOT displayed | Karpo / Atly |
| Neighborhood: Elmhurst (Atly) vs Jackson Heights (Karpo) | Differs by source; the postal address is used as given | Atly / Karpo |
| Full menu item names (teas, boba milk tea, fruit tea, lassi, slushy, yogurt, coffee, momo, laphing, ramen, etc.) | From printed-menu photos (Aug 2026 + Jun 2026), supplied by agency owner | Customer Google Maps photos |
| Prices: Lassi M $4.99/L $5.99; Chatpate, Laphing, Spicy Reman, Beef Ramen, Spicy Potato $7.99; Beef Momo $9.99; Veg. Momo $8.99; Egg Ramen $6.99 | Legible in Aug 2026 menu photo; confirm | same |
| Drink prices (boba, fruit tea, coffee, etc.) | NOT shown: blurry, and the Jun and Aug menus disagree | same |
| Phone (929) 608-4791 | Read from printed-menu footer; last digits should be confirmed | same |
| **Hours, most drink prices, website, Instagram, email, photos, founding story, Liangfen price (not on the photographed menu)** | **NOT verified: shown as "to be confirmed"** | Sources unreachable from the build environment |

Note: Yelp lists a *different* business (Bobba Hubba) at the same address, so its hours were NOT used.

## Second research pass (2026-11-10)
Search again surfaced only the Atly and Karpo listings. Google Maps, Instagram, Yelp and the stock-photo sites (Unsplash, Pexels, Wikimedia) were unreachable from the build environment, so hours, phone, prices and photos remain unverified.

## Needed from you
Screenshots (or pasted text) of the Google Maps listing (hours, phone, photos), the café's Instagram/menu, and any price list.
Then fill `data/business-data.ts` and `data/menu.ts` (`price`, `hours`, `phone`...); the UI updates automatically.
`demoPrice` values in `data/menu.ts` are placeholders for the ordering demo only.
