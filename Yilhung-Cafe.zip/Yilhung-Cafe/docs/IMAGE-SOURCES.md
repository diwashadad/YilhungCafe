# Image sources

**No photos of Yilhung Cafe are currently used.** All imagery is original **illustration** drawn in-house for this demo (`components/art.tsx`), so no third-party licence applies. Every illustration carries an "Illustration" tag, and the gallery states plainly that they are not photos of the café. `components/photo-slot.tsx` is the slot for real, authorized photos. No other café's photos are used as stand-ins.

Stock sites (Unsplash/Pexels/Wikimedia) were unreachable from the build environment, which is why illustration was used.

Customer-uploaded Google Maps photos supplied as screenshots (menu boards, drinks, food) were used **only to read facts** (item names, legible prices, phone). They are not displayed, copied or rehosted.

Why: the research environment could not reach Google Maps/Places, Instagram or listing sites, and
no permission or license for any photo has been confirmed.

## Options to fill the slots (pick per photo)
1. **Owner permission** (best): ask the café for photos in writing, then add to `public/images/` and set `src` + `attribution`.
2. **Google Places API (Place Photos)**: server-side fetch with your API key; show the required author attributions; follow Google Maps Platform terms (display/caching limits; no rehosting customer photos).
3. **Licensed stock** clearly labeled as illustrative (never captioned as Yilhung Cafe).

Where to plug in: `app/page.tsx` (hero/crafts), `components/menu-card.tsx`, `app/gallery/page.tsx` (`photos` array).

| Slot | Current | Source | License / permission | Attribution |
|---|---|---|---|---|
| Hero, crafts, menu cards, gallery | Placeholder | none | n/a | n/a |
