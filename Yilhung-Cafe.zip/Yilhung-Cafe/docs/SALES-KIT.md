# Sales kit: Yilhung Cafe

**Rules:** always call it an *unofficial concept*. Don't claim the café has no website unless you've confirmed (I couldn't verify either way, so say "I couldn't find one"). Don't share the link publicly until you've spoken to the owner. Send it privately.

## Before you pitch (fix these, they affect trust)
- Confirm **hours** and the **phone** digits, and the **drink prices** (menu photos were blurry and two menu versions differ).
- Ask the owner for **their own photos** (or permission to use specific Google Maps photos). The demo uses illustrations.

## 30-second pitch
"Hi, I'm [Name]. I build websites for local businesses. I love what Yilhung does: butter tea, boba, lassi and momo in Elmhurst. I made an *unofficial* concept of what your website could look like: your menu with prices, directions to 40-36 75th St, and a preview of online pickup ordering. It's private. Can I send you the link? If you like it, I'll put in your real photos and details, and you'd own it outright."

## Benefits for the café (plain language)
- Customers searching on their phone see your full menu, location and hours immediately.
- One tap for directions and calls.
- Shows off the Himalayan crafts and butter tea, which make you different from other cafés.
- A path to pickup ordering later (the demo shows how; real orders and payments would be a separate, optional add-on).
- You own it: no monthly fee to me.

## Email draft
> **Subject:** A free website concept for Yilhung Cafe
>
> Hi [Owner name],
>
> I'm [Your name], a local web designer. I'm a fan of Yilhung Cafe, so I put together a private, **unofficial** website concept to show what a site could look like for you: your menu, a map and directions to 40-36 75th St, and a demo of pickup ordering.
>
> Here it is (private link): [link]
>
> Everything marked "to be confirmed" is a placeholder: hours, some prices, and photos (the demo uses illustrations, not your photos). If you like it, I can finish it with your real photos and details and hand you full ownership of the site and domain.
>
> No pressure either way. Happy to chat, or to take it down.
>
> [Your name] · [phone] · [email]

## Price suggestion (one-time fee)
Your market and scope are the judge, but for a polished 6–7-page small-business site with a menu, map, contact form and a demo-quality ordering page:
- **Starter ~$600–$800**: site with their real photos and info, hosting set up on *their* Cloudflare account.
- **Standard ~$900–$1,300**: Starter + custom domain setup, contact form delivery, analytics, a revision round, 30 days support. *(Anchor here.)*
- **Add-ons**: real online ordering/payments (Square/Toast/Stripe integration) quoted separately; menu/photo updates by the hour or a small monthly care plan if they want it.
Client pays their own domain (~$10–15/yr).
