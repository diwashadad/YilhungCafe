# Deploying to Cloudflare (existing account)

> **Status:** prepared and tested locally with Wrangler (Cloudflare's local Worker runtime): all pages, the contact endpoint,
> the `noindex` header and the 404 page work. **Nothing has been deployed.** Cloudflare's dashboard and docs
> were unreachable from the build environment, so the dashboard steps below are written from general knowledge and
> search snippets. Menu names can shift slightly; if a screen differs, trust the dashboard.

## How this project is set up
- The site is a **static export** of Next.js (`out/` folder) with a **tiny Worker** (`worker/index.ts`) that only handles `POST /api/contact`.
- `wrangler.jsonc` tells Cloudflare: serve `./out` as static assets; run the Worker only for `/api/*`.
- `public/_headers` adds `X-Robots-Tag: noindex` so search engines ignore the demo. **Delete that line only when the owner approves a public launch.**

## Pages vs Workers (plain English)
- **Pages**: Cloudflare's older product for static sites and framework sites. Still works, but Cloudflare's own guidance for new projects (including Next.js) has moved toward Workers.
- **Workers (with static assets)**: Cloudflare's newer, recommended home for sites. It serves your files *and* can run a little code (our contact form). One product, one dashboard.
- **This project uses Workers**, because the contact form needs a bit of code and Workers is where Cloudflare is investing.
- Why not run Next.js's own server on Cloudflare? Cloudflare's adapter route (OpenNext) was limited to Next 15 when I checked, and this site uses Next 16. Static export avoids the compatibility risk.

## One-time local check (on your computer)
```bash
cd ~/Desktop/Website/Yilhung-Cafe
npm install
npm run preview        # builds, then serves at http://localhost:8787 using Cloudflare's local runtime
```

## Deploy: easiest path (GitHub to Cloudflare, auto-deploy)
1. Push the project to a **private** GitHub repo (see `docs/GITHUB.md`).
2. Cloudflare dashboard → **Workers & Pages → Create → Import a repository** (Workers Builds). Authorize GitHub, pick `Yilhung-Cafe`, branch `main`.
3. Settings: **Build command** `npm run build` · **Deploy command** `npx wrangler deploy` · Root directory: blank.
4. Save and deploy. You get `https://yilhung-cafe-demo.<your-subdomain>.workers.dev`.
5. Every push to `main` redeploys automatically.

## Deploy: command line alternative
```bash
npx wrangler login     # opens a browser; log in with your existing Cloudflare account
npm run deploy
```

## Contact form destination
Dashboard → your Worker → **Settings → Variables and Secrets**. Add either `CONTACT_WEBHOOK_URL`, or `RESEND_API_KEY` + `CONTACT_TO_EMAIL` + `CONTACT_FROM_EMAIL`. With none, the form works in **demo mode** (validates, shows a thank-you, delivers nothing).

## Version history and rollback
Worker → **Deployments / Versions** tab → pick an earlier version → **Rollback**. (Git history is also a safety net: `git revert` + push redeploys.)

## Analytics
- Quick: Worker → **Metrics** (requests/errors).
- Visitor analytics: **Web Analytics** (free) in the dashboard; it may need the site on a custom domain or a snippet. Check the current setup screen. Add it when the client's domain is connected.

## Cost (verify current pricing before quoting a client)
Static asset requests on Workers have been free and unlimited, with a free tier for Worker (code) requests (the contact form is tiny). A paid Workers plan is a flat monthly fee. Custom domains cost whatever the registrar charges (about $10-15/year for .com). Check cloudflare.com/plans and the Workers pricing page.

## Custom domain (after the client buys it)
Client buys the domain in **their own** name (Cloudflare Registrar, Namecheap or GoDaddy). Worker → **Settings → Domains & Routes → Add custom domain**. If DNS is on Cloudflare this is automatic, with HTTPS issued for you. If the domain is at another registrar, either switch its nameservers to Cloudflare (recommended) or add the CNAME Cloudflare shows. Then remove the `noindex` line in `public/_headers`, add `sitemap.ts` URLs, delete the demo disclaimer **only with the café's written approval**, and redeploy.

## Ownership handover
See `docs/HANDOVER.md`.
