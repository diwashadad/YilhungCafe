"use client";
import Link from "next/link";
import { Plus } from "lucide-react";
import { motion } from "motion/react";
import type { MenuItem } from "@/data/menu";
import { Badge } from "./ui/badge";
import { Illustration } from "./illustration";
import { artBgFor, artFor } from "./art";
import { cn } from "@/lib/utils";

export function MenuCard({ item, className }: { item: MenuItem; className?: string }) {
  return (
    <motion.article whileHover={{ y: -4 }} transition={{ type: "spring", stiffness: 300, damping: 24 }}
      className={cn("group flex h-full flex-col overflow-hidden rounded-[1.75rem] border border-espresso/10 bg-paper shadow-[0_1px_0_rgb(43_29_22/.04),0_14px_34px_-22px_rgb(43_29_22/.45)]", className)}>
      <Illustration className={cn("aspect-[5/4]", artBgFor[item.art])}>
        <div className="absolute inset-0 grid place-items-center p-6 transition-transform duration-500 group-hover:scale-105"><div className="size-full max-w-56">{artFor[item.art]}</div></div>
      </Illustration>
      <div className="flex flex-1 flex-col p-5">
        <div className="flex flex-wrap gap-1.5">{item.tags?.map((t) => <Badge key={t}>{t}</Badge>)}</div>
        <h3 className="mt-3 text-xl font-semibold leading-tight">{item.name}</h3>
        <p className="mt-1.5 text-sm leading-relaxed text-roast/85">{item.description}</p>
        {item.flavors ? <p className="mt-3 flex-1 text-xs leading-relaxed text-roast/75"><span className="font-semibold text-roast">Flavors:</span> {item.flavors.join(", ")}</p> : <div className="flex-1" />}
        <div className="mt-4 flex items-center justify-between gap-3 border-t border-espresso/10 pt-4">
          <span className="text-xs font-medium leading-tight text-roast/70">{item.sizes ? <>M ${item.sizes.m.toFixed(2)}<br />L ${item.sizes.l.toFixed(2)}</> : item.price === null ? <>Price<br />to be confirmed</> : <span className="text-base font-semibold text-espresso">${item.price.toFixed(2)}</span>}</span>
          <Link href={`/order?item=${item.id}`} className="inline-flex min-h-11 shrink-0 items-center gap-1.5 whitespace-nowrap rounded-full bg-espresso px-4 text-sm font-semibold text-cream transition-colors hover:bg-terracotta">
            <Plus className="size-4" aria-hidden /> Try in demo
          </Link>
        </div>
      </div>
    </motion.article>
  );
}
