import { cn } from "@/lib/utils";

/** Five muted colour blocks — a quiet nod to Himalayan textile palettes. Decorative only. */
export function FlagStripe({ className }: { className?: string }) {
  const c = ["bg-flag-blue", "bg-cream-deep", "bg-flag-red", "bg-flag-green", "bg-flag-yellow"];
  return (
    <div aria-hidden className={cn("flex h-1.5 w-full overflow-hidden rounded-full", className)}>
      {c.map((k) => <span key={k} className={cn("flex-1", k)} />)}
    </div>
  );
}

/** Layered mountain ridge, used as a section divider. */
export function Ridge({ className, fill = "var(--color-espresso)", flip }: { className?: string; fill?: string; flip?: boolean }) {
  return (
    <svg aria-hidden viewBox="0 0 1440 120" preserveAspectRatio="none" className={cn("block h-16 w-full md:h-24", flip && "rotate-180", className)}>
      <path fill={fill} d="M0 120V78L120 44L210 84L360 22L490 92L600 40L740 106L900 26L1020 86L1150 36L1300 92L1440 52V120Z" />
    </svg>
  );
}

/** Concentric geometric mandala-style line motif (abstract, non-religious). */
export function Rosette({ className }: { className?: string }) {
  return (
    <svg aria-hidden viewBox="0 0 200 200" className={cn("text-gold", className)} fill="none" stroke="currentColor" strokeWidth="1">
      {[90, 72, 54, 36, 18].map((r) => <circle key={r} cx="100" cy="100" r={r} />)}
      {Array.from({ length: 12 }).map((_, i) => (
        <line key={i} x1="100" y1="10" x2="100" y2="190" transform={`rotate(${i * 15} 100 100)`} />
      ))}
    </svg>
  );
}
