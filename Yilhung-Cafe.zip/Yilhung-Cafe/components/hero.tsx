"use client";
import Link from "next/link";
import { motion, useReducedMotion } from "motion/react";
import { MapPin } from "lucide-react";
import { Button } from "./ui/button";
import { FlagStripe } from "./himalayan";
import { ButterTeaArt, HeroBackdrop } from "./art";

const lines = ["Butter tea,", "boba & street", "snacks, poured", "in Elmhurst."];

export function Hero() {
  const reduce = useReducedMotion();
  const enter = (i: number) => reduce ? {} : { initial: { opacity: 0, y: 28 }, animate: { opacity: 1, y: 0 }, transition: { duration: 0.8, delay: 0.15 + i * 0.11, ease: [0.22, 1, 0.36, 1] as const } };
  return (
    <section className="px-3 pt-3 md:px-6 md:pt-5">
      <div className="relative isolate mx-auto min-h-[46rem] max-w-7xl overflow-hidden rounded-[2rem] bg-espresso md:min-h-[46rem] md:rounded-[2.75rem]">
        <HeroBackdrop />
        <div className="absolute inset-0 bg-linear-to-r from-espresso/80 via-espresso/35 to-transparent md:via-espresso/20" />
        <div className="absolute inset-x-0 bottom-0 h-1/3 bg-linear-to-t from-espresso/70 to-transparent" />

        <div className="absolute -right-6 top-6 w-52 sm:w-72 md:-right-2 md:top-auto md:bottom-14 md:w-[30rem] lg:right-10">
          <motion.div {...(reduce ? {} : { initial: { opacity: 0, scale: 0.9 }, animate: { opacity: 1, scale: 1 }, transition: { duration: 1.1, delay: 0.5, ease: [0.22, 1, 0.36, 1] as const } })}>
            <div className="bob drop-shadow-[0_30px_40px_rgb(0_0_0/.35)]"><ButterTeaArt animated /></div>
          </motion.div>
        </div>

        <div className="relative flex min-h-[46rem] flex-col justify-end p-6 pb-14 sm:p-8 sm:pb-16 md:min-h-[46rem] md:max-w-[46rem] md:p-14 md:pb-20">
          <motion.div {...enter(0)}><FlagStripe className="mb-7 w-28" /></motion.div>
          <h1 className="text-[2.9rem] font-medium leading-[1] text-cream sm:text-6xl md:text-[5.25rem]" aria-label={lines.join(" ")}>
            {lines.map((l, i) => (<motion.span key={l} {...enter(i + 1)} className="block" aria-hidden>{l}</motion.span>))}
          </h1>
          <motion.p {...enter(5)} className="mt-6 max-w-md text-lg leading-relaxed text-cream/90">
            Himalayan butter tea, boba milk tea, lattes and passion fruit refreshers, in a welcoming café with a corner of Himalayan crafts.
          </motion.p>
          <motion.div {...enter(6)} className="mt-8 flex flex-wrap gap-3">
            <Button asChild variant="gold" className="px-7"><Link href="/order">Order (demo)</Link></Button>
            <Button asChild variant="outline" className="border-cream/50 px-7 text-cream hover:bg-cream/10"><Link href="/visit"><MapPin className="size-4" aria-hidden /> Visit us</Link></Button>
          </motion.div>
        </div>
        <p className="absolute bottom-3 right-5 text-[11px] font-medium text-cream/70">Illustrated scene, not a photo of the café</p>
      </div>
    </section>
  );
}
