"use client";
import * as React from "react";
import { CheckCircle2 } from "lucide-react";
import { Button } from "./ui/button";
import { Input, Textarea } from "./ui/input";
import { Label } from "./ui/label";

export function ContactForm() {
  const [state, setState] = React.useState<"idle" | "sending" | "done">("idle");
  const [mode, setMode] = React.useState("");
  const [errors, setErrors] = React.useState<Record<string, string>>({});
  async function onSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    setState("sending"); setErrors({});
    try {
      const res = await fetch("/api/contact", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify(Object.fromEntries(fd)) });
      const j = await res.json();
      if (j.ok) { setMode(j.mode); setState("done"); } else { setErrors(j.errors ?? { form: "Something went wrong." }); setState("idle"); }
    } catch { setErrors({ form: "Network error. Please try again." }); setState("idle"); }
  }
  if (state === "done") return (
    <div role="status" className="rounded-3xl border border-flag-green/40 bg-paper p-8">
      <CheckCircle2 className="size-8 text-flag-green" aria-hidden />
      <h2 className="mt-3 text-2xl font-medium">Thank you!</h2>
      <p className="mt-2 text-roast">{mode === "demo" ? "Demo mode: your message was validated but not delivered, because no destination is configured yet." : "Your message has been sent."}</p>
    </div>
  );
  const err = (k: string) => errors[k] && <p id={`${k}-err`} className="mt-1 text-sm font-medium text-terracotta-deep">{errors[k]}</p>;
  return (
    <form onSubmit={onSubmit} noValidate className="space-y-5">
      <div><Label htmlFor="name">Name</Label><Input id="name" name="name" autoComplete="name" required aria-invalid={!!errors.name} aria-describedby="name-err" className="mt-1.5" />{err("name")}</div>
      <div><Label htmlFor="email">Email</Label><Input id="email" name="email" type="email" autoComplete="email" required aria-invalid={!!errors.email} aria-describedby="email-err" className="mt-1.5" />{err("email")}</div>
      <div><Label htmlFor="message">Message</Label><Textarea id="message" name="message" required aria-invalid={!!errors.message} aria-describedby="message-err" className="mt-1.5" />{err("message")}</div>
      <div className="absolute -left-[9999px]" aria-hidden><label>Website<input name="website" tabIndex={-1} autoComplete="off" /></label></div>
      {errors.form && <p role="alert" className="font-medium text-terracotta-deep">{errors.form}</p>}
      <Button type="submit" variant="terracotta" disabled={state === "sending"}>{state === "sending" ? "Sending…" : "Send message"}</Button>
    </form>
  );
}
