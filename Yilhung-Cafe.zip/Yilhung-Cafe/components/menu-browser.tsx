"use client";
import * as React from "react";
import Link from "next/link";
import { Plus, Search } from "lucide-react";
import { categories, listCategories, menu } from "@/data/menu";
import { cn } from "@/lib/utils";
import { MenuCard } from "./menu-card";
import { Input } from "./ui/input";

export function MenuBrowser() {
  const [q, setQ] = React.useState("");
  const [cat, setCat] = React.useState<string>("All");
  const shown = menu.filter((m) => (cat === "All" || m.category === cat) &&
    (m.name + " " + m.description + " " + (m.tags ?? []).join(" ") + " " + (m.flavors ?? []).join(" ")).toLowerCase().includes(q.trim().toLowerCase()));
  return (
    <div>
      <div className="sticky top-16 z-30 -mx-5 flex flex-col gap-3 border-b border-espresso/10 bg-cream/95 px-5 py-3 backdrop-blur md:flex-row md:items-center md:justify-between md:px-8 md:-mx-8">
        <div className="relative md:w-80">
          <Search className="pointer-events-none absolute left-4 top-1/2 size-4 -translate-y-1/2 text-roast/60" aria-hidden />
          <label htmlFor="menu-search" className="sr-only">Search the menu</label>
          <Input id="menu-search" type="search" value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search the menu" className="pl-11" />
        </div>
        <div role="group" aria-label="Filter by category" className="-mx-5 flex gap-2 overflow-x-auto px-5 pb-1 [scrollbar-width:none] md:mx-0 md:flex-wrap md:overflow-visible md:px-0 md:pb-0">
          {["All", ...categories].map((c) => (
            <button key={c} aria-pressed={cat === c} onClick={() => setCat(c)}
              className={cn("min-h-11 shrink-0 whitespace-nowrap rounded-full border px-4 text-sm font-semibold transition-colors", cat === c ? "border-espresso bg-espresso text-cream" : "border-espresso/25 hover:bg-espresso/5")}>{c}</button>
          ))}
        </div>
      </div>
      <p className="sr-only" role="status">{shown.length} items shown</p>
      {shown.length === 0 ? <p className="mt-12 text-roast">Nothing matches “{q}”. Try another word.</p> : (
        <div className="mt-10 space-y-14">
          {categories.filter((c) => shown.some((m) => m.category === c)).map((c) => (
            <section key={c} aria-labelledby={`cat-${c}`}>
              <h2 id={`cat-${c}`} className="mb-5 flex items-baseline gap-3 border-b border-espresso/15 pb-3 text-3xl font-medium md:text-4xl">{c}<span className="font-sans text-sm font-semibold text-roast/60">{shown.filter((m) => m.category === c).length}</span></h2>
              {listCategories.includes(c) ? (
                <ul className="grid gap-x-12 md:grid-cols-2">
                  {shown.filter((m) => m.category === c).map((m) => (
                    <li key={m.id} className="flex items-baseline gap-3 border-b border-dashed border-espresso/25 py-3">
                      <span className="font-display text-lg font-medium">{m.name}</span>
                      <span aria-hidden className="flex-1" />
                      <span className="text-xs font-medium text-roast/70">{m.price === null ? "Price to be confirmed" : `$${m.price.toFixed(2)}`}</span>
                      <Link href={`/order?item=${m.id}`} aria-label={`Try ${m.name} in the demo`} className="grid size-9 shrink-0 place-items-center rounded-full bg-espresso text-cream hover:bg-terracotta"><Plus className="size-4" aria-hidden /></Link>
                    </li>
                  ))}
                </ul>
              ) : (
                <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">{shown.filter((m) => m.category === c).map((m) => <MenuCard key={m.id} item={m} />)}</div>
              )}
            </section>
          ))}
        </div>
      )}
    </div>
  );
}
