import * as React from "react";

/**
 * Original illustrations drawn for this demo (authored in-house, no third-party license needed).
 * They are ILLUSTRATIONS, never photos of Yilhung Cafe. See docs/IMAGE-SOURCES.md.
 */
const C = { cream: "#f6efe3", paper: "#fbf7ef", espresso: "#2b1d16", roast: "#4a3226", terra: "#a9503a", terraDeep: "#8a3e2b", gold: "#b08d4f", goldSoft: "#d9c395", blue: "#46627f", green: "#6b8561", yellow: "#c9a24b", red: "#a8452f" };

function Steam({ x = 100, y = 60, animated, scale = 1 }: { x?: number; y?: number; animated?: boolean; scale?: number }) {
  const p = (dx: number, delay: number) => (
    <path key={dx} className={animated ? "steam" : undefined} style={{ animationDelay: `${delay}s` }}
      d={`M${x + dx} ${y} c-10 -14 10 -24 0 -40 c-8 -12 6 -22 0 -34`} fill="none" stroke="currentColor" strokeWidth={4 * scale} strokeLinecap="round" opacity=".55" />
  );
  return <g color={C.paper}>{p(-18, 0)}{p(0, 0.8)}{p(18, 1.6)}</g>;
}

export function ButterTeaArt({ animated }: { animated?: boolean }) {
  return (
    <svg viewBox="0 0 200 200" role="img" aria-label="Illustration of a bowl of butter tea" className="size-full">
      <ellipse cx="100" cy="172" rx="62" ry="8" fill={C.espresso} opacity=".25" />
      <path d="M44 100h112c0 38-24 62-56 62s-56-24-56-62z" fill={C.terra} />
      <path d="M44 100h112c0 10-1.5 19-4.5 27H48.500c-3-8-4.500-17-4.500-27z" fill={C.terraDeep} />
      <path d="M60 126h80" stroke={C.goldSoft} strokeWidth="3" strokeDasharray="2 7" strokeLinecap="round" />
      <rect x="78" y="158" width="44" height="10" rx="4" fill={C.roast} />
      <ellipse cx="100" cy="100" rx="56" ry="11" fill={C.gold} />
      <ellipse cx="100" cy="101" rx="50" ry="8" fill="#e7cf9a" />
      <ellipse cx="88" cy="100" rx="14" ry="3" fill={C.paper} opacity=".55" />
      <Steam x={100} y={82} animated={animated} />
    </svg>
  );
}

export function BobaArt() {
  const pearls = [[72, 164], [86, 168], [100, 165], [114, 168], [128, 164], [79, 154], [93, 157], [107, 155], [121, 157], [100, 146]];
  return (
    <svg viewBox="0 0 200 200" role="img" aria-label="Illustration of a boba milk tea" className="size-full">
      <ellipse cx="100" cy="184" rx="44" ry="6" fill={C.espresso} opacity=".25" />
      <rect x="132" y="14" width="9" height="86" rx="4" fill={C.terra} transform="rotate(14 136 60)" />
      <path d="M62 52h76l-10 124c-.6 6-5 9-11 9H83c-6 0-10.400-3-11-9z" fill={C.paper} opacity=".9" />
      <path d="M66 78h68l-8.500 98c-.5 6-5 9-11 9H85.500c-6 0-10.500-3-11-9z" fill="#c79f78" />
      <path d="M68 96h64" stroke="#e3c9a6" strokeWidth="5" opacity=".6" />
      {pearls.map(([x, y]) => <circle key={`${x}-${y}`} cx={x} cy={y} r="6.500" fill={C.espresso} />)}
      <rect x="58" y="42" width="84" height="14" rx="7" fill={C.roast} />
      <path d="M74 66v90" stroke={C.paper} strokeWidth="4" opacity=".5" strokeLinecap="round" />
    </svg>
  );
}

export function LatteArt() {
  return (
    <svg viewBox="0 0 200 200" role="img" aria-label="Illustration of a latte with leaf latte art" className="size-full">
      <circle cx="100" cy="104" r="84" fill={C.paper} />
      <circle cx="100" cy="104" r="84" fill="none" stroke={C.goldSoft} strokeWidth="3" />
      <rect x="164" y="92" width="26" height="14" rx="7" fill={C.paper} />
      <circle cx="100" cy="100" r="62" fill={C.roast} />
      <circle cx="100" cy="100" r="54" fill="#8a5a3c" />
      <path d="M100 56c22 14 30 40 0 84-30-44-22-70 0-84z" fill={C.cream} />
      <path d="M100 66v68" stroke="#8a5a3c" strokeWidth="2.500" strokeLinecap="round" />
      {[78, 92, 106, 120].map((y, i) => (<g key={y}><path d={`M100 ${y}l${-16 + i * 2} ${-8}`} stroke="#8a5a3c" strokeWidth="2" strokeLinecap="round" /><path d={`M100 ${y}l${16 - i * 2} ${-8}`} stroke="#8a5a3c" strokeWidth="2" strokeLinecap="round" /></g>))}
    </svg>
  );
}

export function PassionFruitArt() {
  const seeds = [[0, 0], [10, -6], [-9, -8], [8, 9], [-10, 7], [0, 14], [0, -15], [17, 2], [-17, 0]];
  return (
    <svg viewBox="0 0 200 200" role="img" aria-label="Illustration of a passion fruit refresher with a halved passion fruit" className="size-full">
      <ellipse cx="100" cy="186" rx="50" ry="6" fill={C.espresso} opacity=".25" />
      <rect x="104" y="10" width="8" height="90" rx="4" fill={C.green} transform="rotate(-10 108 55)" />
      <path d="M56 40h88l-10 132c-.5 7-5.500 12-12 12H78c-6.500 0-11.500-5-12-12z" fill={C.paper} opacity=".85" />
      <defs><linearGradient id="pf" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor="#f2b84b" /><stop offset="1" stopColor="#d9692f" /></linearGradient></defs>
      <path d="M60 68h80l-8 104c-.5 7-5.500 12-12 12H80c-6.500 0-11.500-5-12-12z" fill="url(#pf)" />
      <rect x="76" y="82" width="26" height="26" rx="5" fill={C.paper} opacity=".45" transform="rotate(-12 89 95)" />
      <rect x="104" y="112" width="24" height="24" rx="5" fill={C.paper} opacity=".4" transform="rotate(10 116 124)" />
      <g transform="translate(156 150)">
        <circle r="26" fill="#5b3a5e" /><circle r="20" fill="#f0c95a" /><circle r="13" fill="#e59a3a" />
        {seeds.map(([x, y]) => <ellipse key={`${x}${y}`} cx={x} cy={y} rx="2.500" ry="3.500" fill={C.espresso} />)}
      </g>
    </svg>
  );
}

export function ChatpatArt() {
  const bits = Array.from({ length: 34 }).map((_, i) => {
    const a = (i * 137.5) * Math.PI / 180, r = 6 + (i % 9) * 6.200;
    return { x: 100 + Math.cos(a) * r, y: 96 + Math.sin(a) * r * 0.55, k: i % 5, rot: (i * 47) % 180 };
  });
  const fill = ["#e0b86a", "#c98443", "#f0dba8", C.green, C.red];
  return (
    <svg viewBox="0 0 200 200" role="img" aria-label="Illustration of a bowl of chatpat snack" className="size-full">
      <ellipse cx="100" cy="176" rx="64" ry="7" fill={C.espresso} opacity=".25" />
      <path d="M32 98h136c0 40-28 70-68 70S32 138 32 98z" fill={C.blue} />
      <path d="M32 98h136c0 8-1 15-3 22H35c-2-7-3-14-3-22z" fill="#3a526b" />
      <path d="M52 134h96" stroke={C.goldSoft} strokeWidth="3" strokeDasharray="2 7" strokeLinecap="round" />
      <ellipse cx="100" cy="98" rx="68" ry="14" fill={C.roast} />
      {bits.map((b, i) => <rect key={i} x={b.x - 5} y={b.y - 7} width={b.k > 2 ? 5 : 10} height={b.k > 2 ? 5 : 6} rx="2" transform={`rotate(${b.rot} ${b.x} ${b.y})`} fill={fill[b.k]} />)}
      <path d="M84 74q16-22 32 0" stroke={C.red} strokeWidth="0" fill="none" />
    </svg>
  );
}

export function LiangfenArt() {
  return (
    <svg viewBox="0 0 200 200" role="img" aria-label="Illustration of a bowl of liangfen jelly noodles" className="size-full">
      <ellipse cx="100" cy="176" rx="64" ry="7" fill={C.espresso} opacity=".25" />
      <path d="M32 98h136c0 40-28 70-68 70S32 138 32 98z" fill={C.paper} />
      <path d="M32 98h136c0 8-1 15-3 22H35c-2-7-3-14-3-22z" fill={C.cream} />
      <path d="M50 134h100" stroke={C.terra} strokeWidth="3" strokeDasharray="2 7" strokeLinecap="round" />
      <ellipse cx="100" cy="98" rx="68" ry="14" fill="#e7c98a" />
      {Array.from({ length: 11 }).map((_, i) => <rect key={i} x={46 + i * 10} y={88 + (i % 3) * 3} width="5" height="20" rx="2.500" fill="#f2dfae" opacity=".9" transform={`rotate(${(i - 5) * 4} ${48 + i * 10} 98)`} />)}
      <ellipse cx="100" cy="95" rx="30" ry="6" fill={C.red} opacity=".85" />
      {[[78, 92], [92, 100], [110, 91], [124, 99], [102, 89]].map(([x, y]) => <rect key={x} x={x} y={y} width="9" height="3.500" rx="1.700" fill={C.green} transform={`rotate(${x} ${x} ${y})`} />)}
    </svg>
  );
}

export const artFor: Record<string, React.ReactNode> = {
  "butter-tea": <ButterTeaArt />, boba: <BobaArt />, latte: <LatteArt />, iced: <IcedCoffeeArt />, fruit: <PassionFruitArt />,
  lassi: <LassiArt />, slushy: <SlushyArt />, chatpat: <ChatpatArt />, liangfen: <LiangfenArt />, momo: <MomoArt />,
};
export const artBgFor: Record<string, string> = {
  "butter-tea": "bg-[#e9d3a8]", boba: "bg-[#e8cdb8]", latte: "bg-[#d9c3a5]", iced: "bg-[#e4d2c0]", fruit: "bg-[#f1dca6]",
  lassi: "bg-[#f3e6b8]", slushy: "bg-[#f3d0d3]", chatpat: "bg-[#c9d3d9]", liangfen: "bg-[#ecd2c3]", momo: "bg-[#dcc6a6]",
};

/** Layered dusk-over-the-ridges backdrop. */
export function HeroBackdrop() {
  return (
    <svg aria-hidden viewBox="0 0 1600 900" preserveAspectRatio="xMidYMax slice" className="absolute inset-0 size-full">
      <defs>
        <linearGradient id="sky" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#2b1d16" /><stop offset=".45" stopColor="#6b3526" /><stop offset=".78" stopColor="#c6724a" /><stop offset="1" stopColor="#e6b878" />
        </linearGradient>
        <radialGradient id="sun" cx=".5" cy=".5" r=".5"><stop offset="0" stopColor="#f6e2b0" /><stop offset=".6" stopColor="#e9b873" stopOpacity=".55" /><stop offset="1" stopColor="#e9b873" stopOpacity="0" /></radialGradient>
      </defs>
      <rect width="1600" height="900" fill="url(#sky)" />
      <circle cx="1130" cy="500" r="260" fill="url(#sun)" />
      <circle cx="1130" cy="500" r="74" fill="#f6e2b0" />
      <g className="drift-slow">
        <path d="M-80 640 L160 430 L260 520 L420 330 L560 480 L700 380 L860 540 L1010 360 L1180 520 L1330 410 L1480 540 L1700 400 V900 H-80Z" fill="#8d5a4a" opacity=".55" />
        <path d="M420 330l36 38-30-10-22 22-20-22zM1010 360l32 34-26-8-20 20-18-20zM700 380l24 26-18-6-14 14z" fill="#f6efe3" opacity=".55" />
      </g>
      <path d="M-80 720 L120 580 L300 670 L520 500 L700 650 L900 540 L1100 680 L1300 560 L1500 690 L1700 600 V900 H-80Z" fill="#5a3326" opacity=".85" />
      <path d="M-80 810 L180 690 L380 770 L620 650 L860 790 L1120 700 L1360 790 L1700 700 V900 H-80Z" fill="#3a241b" />
      <rect y="860" width="1600" height="40" fill="#2b1d16" />
    </svg>
  );
}

/** Woven-textile inspired band (abstract geometric; decorative). */
export function TextileBand({ className }: { className?: string }) {
  return (
    <svg aria-hidden className={className} width="100%" height="28" preserveAspectRatio="none">
      <defs>
        <pattern id="tx" width="56" height="28" patternUnits="userSpaceOnUse">
          <rect width="56" height="28" fill={C.espresso} />
          <path d="M0 14 L14 2 L28 14 L14 26z" fill={C.terra} /><path d="M28 14 L42 2 L56 14 L42 26z" fill={C.gold} />
          <path d="M14 14 L21 8 L28 14 L21 20z" fill={C.cream} /><path d="M42 14 L49 8 L56 14 L49 20z" fill={C.blue} />
          <rect y="0" width="56" height="2" fill={C.goldSoft} opacity=".6" /><rect y="26" width="56" height="2" fill={C.goldSoft} opacity=".6" />
        </pattern>
      </defs>
      <rect width="100%" height="28" fill="url(#tx)" />
    </svg>
  );
}

/** Crafts-corner still life: lantern, brass bowl and woven textile (illustrative). */
export function CraftsArt() {
  return (
    <svg viewBox="0 0 400 300" preserveAspectRatio="xMidYMid slice" role="img" aria-label="Illustration of a corner with Himalayan-style crafts" className="size-full">
      <rect width="400" height="300" fill="#4a3226" />
      <rect y="210" width="400" height="90" fill="#2b1d16" />
      <g transform="translate(56 24)"><path d="M0 0h10v26" stroke={C.goldSoft} strokeWidth="2" /><path d="M-14 26h38l-6 70h-26z" fill={C.terra} /><path d="M-14 26h38l-3 20h-32z" fill={C.terraDeep} /><path d="M-4 60h18" stroke={C.goldSoft} strokeWidth="2" /><path d="M-8 96h26" stroke={C.gold} strokeWidth="5" /><circle cx="5" cy="62" r="14" fill={C.goldSoft} opacity=".35" /></g>
      <g transform="translate(300 30)">
        {[0, 1, 2, 3].map((r) => [0, 1, 2, 3].map((c) => <path key={`${r}${c}`} d={`M${c * 22 + 11} ${r * 22} l11 11 l-11 11 l-11 -11z`} fill={[C.terra, C.gold, C.blue, C.cream][(r + c) % 4]} />))}
      </g>
      <g transform="translate(100 150)">
        <ellipse cx="100" cy="86" rx="92" ry="12" fill="#000" opacity=".3" />
        <path d="M10 40h180c0 30-36 52-90 52S10 70 10 40z" fill={C.gold} />
        <path d="M10 40h180c-1 8-4 15-9 21H19c-5-6-8-13-9-21z" fill="#8a6a35" />
        <ellipse cx="100" cy="40" rx="90" ry="12" fill="#e6cf9a" />
        <ellipse cx="100" cy="41" rx="80" ry="8" fill="#9a7a3f" />
        <path d="M40 66h120" stroke="#e6cf9a" strokeWidth="2" strokeDasharray="2 6" />
      </g>
      <path d="M0 214 L40 206 L90 214 L150 204 L210 214 L270 206 L330 214 L400 204 V222 H0z" fill={C.terraDeep} opacity=".6" />
    </svg>
  );
}

export function LassiArt() {
  return (
    <svg viewBox="0 0 200 200" role="img" aria-label="Illustration of a tall glass of lassi" className="size-full">
      <ellipse cx="100" cy="184" rx="40" ry="6" fill={C.espresso} opacity=".25" />
      <path d="M62 40h76l-6 130c-.3 7-5 12-12 12H80c-7 0-11.700-5-12-12z" fill={C.paper} opacity=".9" />
      <defs><linearGradient id="ls" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor="#f7e3a6" /><stop offset="1" stopColor="#efc15b" /></linearGradient></defs>
      <path d="M65 62h70l-5 108c-.3 7-5 12-12 12H82c-7 0-11.700-5-12-12z" fill="url(#ls)" />
      <path d="M65 62c10 8 20 8 35 2s25-6 35 0" fill="#fff6dc" />
      <circle cx="132" cy="48" r="11" fill={C.terra} /><path d="M132 37c2-6 7-8 10-8" stroke={C.green} strokeWidth="3" fill="none" strokeLinecap="round" />
    </svg>
  );
}
export function IcedCoffeeArt() {
  return (
    <svg viewBox="0 0 200 200" role="img" aria-label="Illustration of an iced coffee" className="size-full">
      <ellipse cx="100" cy="184" rx="42" ry="6" fill={C.espresso} opacity=".25" />
      <rect x="112" y="12" width="8" height="90" rx="4" fill={C.espresso} transform="rotate(10 116 57)" />
      <path d="M58 44h84l-9 126c-.5 7-5.500 12-12 12H79c-6.500 0-11.500-5-12-12z" fill={C.paper} opacity=".9" />
      <path d="M62 80h76l-7.500 90c-.5 7-5.500 12-12 12H81.500c-6.500 0-11.500-5-12-12z" fill="#4a2c1c" />
      <path d="M62 80h76l-1.500 16H63.500z" fill="#d9b48a" />
      {[[80, 108], [108, 120], [92, 142], [118, 150]].map(([x, y]) => <rect key={x} x={x} y={y} width="22" height="22" rx="5" fill={C.paper} opacity=".3" transform={`rotate(${x} ${x + 11} ${y + 11})`} />)}
    </svg>
  );
}
export function SlushyArt() {
  return (
    <svg viewBox="0 0 200 200" role="img" aria-label="Illustration of a fruit slushy" className="size-full">
      <ellipse cx="100" cy="184" rx="40" ry="6" fill={C.espresso} opacity=".25" />
      <path d="M60 70h80l-8 100c-.5 7-5.500 12-12 12H80c-6.500 0-11.500-5-12-12z" fill={C.paper} opacity=".9" />
      <path d="M64 92h72l-6 78c-.5 7-5.500 12-12 12H82c-6.500 0-11.500-5-12-12z" fill="#e8647a" />
      <path d="M64 92h72l-1.500 20c-12 6-24-6-34 0s-24-6-36 0z" fill="#f5a3b0" />
      <path d="M62 70c-4-26 26-40 38-34 12-8 40 6 38 34z" fill="#f5a3b0" />
      <path d="M72 56c8-8 18-10 24-8" stroke={C.paper} strokeWidth="4" strokeLinecap="round" opacity=".6" fill="none" />
      <rect x="106" y="14" width="8" height="64" rx="4" fill={C.blue} transform="rotate(12 110 46)" />
    </svg>
  );
}
export function MomoArt() {
  const m = (x: number, y: number, k: number) => (
    <g key={k} transform={`translate(${x} ${y})`}>
      <path d="M-26 6c0-26 52-26 52 0 0 8-6 12-26 12S-26 14-26 6z" fill="#f4e6cc" />
      {[-16, -8, 0, 8, 16].map((dx) => <path key={dx} d={`M${dx} -12 q${dx > 0 ? 3 : -3} 8 ${dx > 0 ? -2 : 2} 16`} stroke="#d9c395" strokeWidth="2.500" fill="none" strokeLinecap="round" />)}
    </g>
  );
  return (
    <svg viewBox="0 0 200 200" role="img" aria-label="Illustration of a plate of momo dumplings" className="size-full">
      <ellipse cx="100" cy="172" rx="76" ry="9" fill={C.espresso} opacity=".25" />
      <ellipse cx="100" cy="140" rx="78" ry="26" fill={C.terra} />
      <ellipse cx="100" cy="136" rx="68" ry="20" fill={C.paper} />
      {m(70, 128, 1)}{m(130, 128, 2)}{m(100, 112, 3)}
      <circle cx="150" cy="150" r="9" fill={C.red} /><path d="M146 146q4-4 8 0" stroke={C.green} strokeWidth="2" fill="none" />
    </svg>
  );
}
