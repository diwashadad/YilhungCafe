import { cn } from "@/lib/utils";

/**
 * Wrapper for in-house ILLUSTRATIONS. Always shows an "Illustration" tag so visitors can tell
 * these apart from real Yilhung Cafe photos (which use <PhotoSlot src=… attribution=…>).
 */
export function Illustration({ children, className, tag = true }: { children: React.ReactNode; className?: string; tag?: boolean }) {
  return (
    <div className={cn("relative overflow-hidden", className)}>
      {children}
      {tag && <span className="absolute bottom-2.5 left-2.5 rounded-full bg-espresso/75 px-2.5 py-0.5 text-[11px] font-semibold tracking-wide text-cream backdrop-blur-sm">Illustration</span>}
    </div>
  );
}
