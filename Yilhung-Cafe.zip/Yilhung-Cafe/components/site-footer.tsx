import Link from "next/link";
import { business, DIRECTIONS_URL, disclaimer } from "@/data/business-data";
import { FlagStripe, Ridge } from "./himalayan";

export function SiteFooter() {
  return (
    <footer className="mt-24 bg-espresso text-cream">
      <Ridge fill="var(--color-cream)" flip className="-mt-px" />
      <div className="mx-auto grid max-w-7xl gap-10 px-5 pb-10 pt-6 md:grid-cols-3 md:px-8">
        <div>
          <p className="font-display text-2xl">Yilhung Cafe</p>
          <p className="mt-3 max-w-xs text-sm text-cream/75">Himalayan butter tea, boba milk tea, lattes, refreshers, chatpat and liangfen in Elmhurst, Queens.</p>
        </div>
        <div className="text-sm">
          <p className="font-semibold text-gold-soft">Find us</p>
          <address className="mt-3 not-italic text-cream/80">{business.address.value.street}<br />{business.address.value.city}, {business.address.value.state} {business.address.value.zip}</address>
          <a className="mt-2 inline-block underline underline-offset-4" href={DIRECTIONS_URL} target="_blank" rel="noopener noreferrer">Get directions (opens Google Maps)</a>
        </div>
        <nav aria-label="Footer" className="grid grid-cols-2 gap-2 text-sm">
          {[["/menu", "Menu"], ["/story", "Our Story"], ["/gallery", "Gallery"], ["/visit", "Visit Us"], ["/contact", "Contact"], ["/order", "Order demo"]].map(([h, l]) => (
            <Link key={h} href={h} className="py-1 text-cream/80 hover:text-gold-soft">{l}</Link>
          ))}
        </nav>
      </div>
      <div className="mx-auto max-w-7xl px-5 pb-8 md:px-8">
        <FlagStripe className="mb-5 opacity-80" />
        <p className="text-sm font-semibold text-gold-soft">{disclaimer}</p>
        <p className="mt-1 text-xs text-cream/60">Demo built by a web agency for portfolio purposes. Details marked “to be confirmed” are not yet verified. The ordering page is a demo: no orders or payments are processed.</p>
      </div>
    </footer>
  );
}
