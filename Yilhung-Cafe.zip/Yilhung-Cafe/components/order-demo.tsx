"use client";
import * as React from "react";
import { useSearchParams } from "next/navigation";
import { Minus, Plus, Trash2, ShoppingBag, CheckCircle2, TriangleAlert } from "lucide-react";
import { categories, menu, type MenuItem } from "@/data/menu";
import { money, TAX_RATE, useCart } from "@/lib/cart";
import { cn } from "@/lib/utils";
import { Button } from "./ui/button";
import { Input, Textarea } from "./ui/input";
import { Label } from "./ui/label";

function Customizer({ item, onClose }: { item: MenuItem; onClose: () => void }) {
  const { add } = useCart();
  const defaults = () => Object.fromEntries((item.groups ?? []).filter((g) => g.required).map((g) => [g.id, g.options[g.id === "sweet" ? 1 : 0].id]));
  const [choices, setChoices] = React.useState<Record<string, string>>(defaults);
  const [qty, setQty] = React.useState(1);
  const [note, setNote] = React.useState("");
  const extra = (item.groups ?? []).reduce((s, g) => s + (g.options.find((o) => o.id === choices[g.id])?.extra ?? 0), 0);
  const cleaned = Object.fromEntries(Object.entries(choices).filter(([, v]) => v !== "none"));
  return (
    <section aria-labelledby="cust-title" className="rounded-3xl border border-terracotta/40 bg-paper p-6">
      <div className="flex items-start justify-between gap-4">
        <div><h3 id="cust-title" className="text-2xl font-medium">{item.name}</h3><p className="text-sm text-roast/80">{item.description}</p></div>
        <Button variant="ghost" size="sm" onClick={onClose}>Close</Button>
      </div>
      {(item.groups ?? []).map((g) => (
        <fieldset key={g.id} className="mt-5">
          <legend className="text-sm font-semibold text-roast">{g.label}</legend>
          <div className="mt-2 flex flex-wrap gap-2">
            {g.options.map((o) => {
              const sel = (choices[g.id] ?? (g.required ? undefined : "none")) === o.id;
              return (
                <label key={o.id} className={cn("flex min-h-11 cursor-pointer items-center rounded-full border px-4 text-sm font-medium has-[:focus-visible]:outline has-[:focus-visible]:outline-2 has-[:focus-visible]:outline-offset-2 has-[:focus-visible]:outline-terracotta", sel ? "border-espresso bg-espresso text-cream" : "border-espresso/25 hover:bg-espresso/5")}>
                  <input type="radio" className="sr-only" name={g.id} checked={sel} onChange={() => setChoices((c) => ({ ...c, [g.id]: o.id }))} />
                  {o.label}{o.extra ? ` +${money(o.extra)}` : ""}
                </label>
              );
            })}
          </div>
        </fieldset>
      ))}
      <div className="mt-5"><Label htmlFor="note">Special instructions (optional)</Label><Input id="note" value={note} maxLength={120} onChange={(e) => setNote(e.target.value)} className="mt-1.5" /></div>
      <div className="mt-6 flex flex-wrap items-center gap-4">
        <Stepper qty={qty} onChange={setQty} label={item.name} />
        <Button variant="terracotta" onClick={() => { add(item.id, cleaned, qty, note.trim() || undefined); onClose(); }}>Add to demo order · {money((item.demoPrice + extra) * qty)}</Button>
      </div>
    </section>
  );
}

function Stepper({ qty, onChange, label }: { qty: number; onChange: (n: number) => void; label: string }) {
  return (
    <div className="inline-flex items-center rounded-full border border-espresso/25">
      <Button variant="ghost" size="icon" aria-label={`Decrease quantity of ${label}`} onClick={() => onChange(qty - 1)}><Minus className="size-4" /></Button>
      <span className="min-w-8 text-center font-semibold" aria-live="polite">{qty}</span>
      <Button variant="ghost" size="icon" aria-label={`Increase quantity of ${label}`} onClick={() => onChange(qty + 1)} disabled={qty >= 20}><Plus className="size-4" /></Button>
    </div>
  );
}

export function OrderDemo() {
  const params = useSearchParams();
  const cart = useCart();
  const [active, setActive] = React.useState<string | null>(params.get("item"));
  const [placed, setPlaced] = React.useState<null | { total: number; name: string; when: string; n: number }>(null);
  const [form, setForm] = React.useState({ name: "", phone: "", when: "asap", note: "" });
  const [errs, setErrs] = React.useState<Record<string, string>>({});
  const activeItem = menu.find((m) => m.id === active);
  const tax = cart.subtotal * TAX_RATE;
  const total = cart.subtotal + tax;

  function place() {
    const e: Record<string, string> = {};
    if (form.name.trim().length < 2) e.name = "Please enter a name for the pickup.";
    if (form.phone && !/^[\d\s().+-]{7,20}$/.test(form.phone)) e.phone = "Enter a valid phone number or leave blank.";
    setErrs(e);
    if (Object.keys(e).length) return;
    setPlaced({ total, name: form.name.trim(), when: form.when, n: cart.count });
    cart.clear();
  }
  const whenLabel = { asap: "As soon as ready", "15": "In about 15 minutes", "30": "In about 30 minutes", "45": "In about 45 minutes" } as Record<string, string>;

  if (placed) return (
    <div role="status" className="mx-auto max-w-xl rounded-3xl border border-flag-green/40 bg-paper p-8 text-center">
      <CheckCircle2 className="mx-auto size-10 text-flag-green" aria-hidden />
      <p className="mt-3 inline-block rounded-full bg-terracotta px-3 py-1 text-xs font-bold text-paper">DEMO ONLY: NO ORDER WAS PLACED</p>
      <h2 className="mt-4 text-3xl font-medium">Demo order complete</h2>
      <p className="mt-3 text-roast">{placed.n} item{placed.n > 1 ? "s" : ""} for {placed.name}, pickup: {whenLabel[placed.when]}. Demo total {money(placed.total)}.</p>
      <p className="mt-2 text-sm text-roast/80">Nothing was sent to Yilhung Cafe and no payment was taken.</p>
      <Button className="mt-6" onClick={() => setPlaced(null)}>Start another demo order</Button>
    </div>
  );

  return (
    <div className="grid gap-8 lg:grid-cols-[1.4fr_1fr]">
      <div className="space-y-8">
        {activeItem && <Customizer key={activeItem.id} item={activeItem} onClose={() => setActive(null)} />}
        {categories.map((c) => (
          <section key={c} aria-labelledby={`o-${c}`}>
            <h2 id={`o-${c}`} className="mb-3 text-xl font-medium">{c}</h2>
            <ul className="divide-y divide-espresso/10 rounded-2xl border border-espresso/10 bg-paper">
              {menu.filter((m) => m.category === c).map((m) => (
                <li key={m.id} className="flex items-center justify-between gap-4 p-4">
                  <div><p className="font-semibold">{m.name}</p><p className="text-sm text-roast/75">Demo price {money(m.demoPrice)}</p></div>
                  <Button variant={active === m.id ? "terracotta" : "outline"} size="sm" onClick={() => setActive(m.id)} aria-label={`Customize and add ${m.name}`}>Add</Button>
                </li>
              ))}
            </ul>
          </section>
        ))}
      </div>

      <aside aria-label="Your demo order" className="h-fit rounded-3xl bg-espresso p-6 text-cream lg:sticky lg:top-24">
        <h2 className="flex items-center gap-2 text-2xl font-medium"><ShoppingBag className="size-5 text-gold-soft" aria-hidden /> Your order <span className="rounded-full bg-gold-soft px-2 py-0.5 font-sans text-xs font-bold text-espresso">DEMO</span></h2>
        {cart.lines.length === 0 ? <p className="mt-6 text-cream/75">Your cart is empty. Pick something to try the flow.</p> : (
          <>
            <ul className="mt-5 space-y-4">
              {cart.lines.map((l) => {
                const it = cart.item(l.itemId);
                const desc = (it.groups ?? []).map((g) => g.options.find((o) => o.id === l.choices[g.id])?.label).filter(Boolean).join(", ");
                return (
                  <li key={l.key} className="border-b border-cream/15 pb-4">
                    <div className="flex justify-between gap-3"><p className="font-semibold">{it.name}</p><p>{money(cart.unitPrice(l) * l.qty)}</p></div>
                    {desc && <p className="text-sm text-cream/70">{desc}</p>}{l.note && <p className="text-sm italic text-cream/70">“{l.note}”</p>}
                    <div className="mt-2 flex items-center justify-between">
                      <div className="inline-flex items-center rounded-full border border-cream/30">
                        <Button variant="ghost" size="icon" className="text-cream hover:bg-cream/10" aria-label={`Decrease quantity of ${it.name}`} onClick={() => cart.setQty(l.key, l.qty - 1)}><Minus className="size-4" /></Button>
                        <span className="min-w-8 text-center font-semibold">{l.qty}</span>
                        <Button variant="ghost" size="icon" className="text-cream hover:bg-cream/10" aria-label={`Increase quantity of ${it.name}`} onClick={() => cart.setQty(l.key, l.qty + 1)}><Plus className="size-4" /></Button>
                      </div>
                      <Button variant="ghost" size="icon" className="text-cream hover:bg-cream/10" aria-label={`Remove ${it.name}`} onClick={() => cart.remove(l.key)}><Trash2 className="size-4" /></Button>
                    </div>
                  </li>
                );
              })}
            </ul>
            <dl className="mt-4 space-y-1 text-sm">
              <div className="flex justify-between"><dt>Subtotal</dt><dd>{money(cart.subtotal)}</dd></div>
              <div className="flex justify-between text-cream/75"><dt>Est. tax (demo)</dt><dd>{money(tax)}</dd></div>
              <div className="flex justify-between border-t border-cream/20 pt-2 text-lg font-semibold"><dt>Total</dt><dd>{money(total)}</dd></div>
            </dl>
            <div className="mt-6 space-y-4 text-espresso">
              <div><Label htmlFor="p-name" className="text-cream">Pickup name</Label><Input id="p-name" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} aria-invalid={!!errs.name} className="mt-1.5" />{errs.name && <p className="mt-1 text-sm text-gold-soft">{errs.name}</p>}</div>
              <div><Label htmlFor="p-phone" className="text-cream">Phone (optional)</Label><Input id="p-phone" type="tel" value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} aria-invalid={!!errs.phone} className="mt-1.5" />{errs.phone && <p className="mt-1 text-sm text-gold-soft">{errs.phone}</p>}</div>
              <div><Label htmlFor="p-when" className="text-cream">Pickup time</Label>
                <select id="p-when" value={form.when} onChange={(e) => setForm({ ...form, when: e.target.value })} className="mt-1.5 min-h-11 w-full rounded-xl border border-espresso/25 bg-paper px-4">
                  {Object.entries(whenLabel).map(([k, v]) => <option key={k} value={k}>{v}</option>)}
                </select></div>
            </div>
            <p className="mt-5 flex gap-2 rounded-xl bg-cream/10 p-3 text-sm"><TriangleAlert className="mt-0.5 size-4 shrink-0 text-gold-soft" aria-hidden /> Demo checkout only. No real orders or payments are accepted. Prices here are placeholders, not Yilhung Cafe’s prices.</p>
            <Button variant="gold" className="mt-4 w-full" onClick={place}>Place demo order</Button>
          </>
        )}
      </aside>
    </div>
  );
}
