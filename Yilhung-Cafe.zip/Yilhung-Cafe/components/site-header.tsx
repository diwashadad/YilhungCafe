"use client";
import Link from "next/link";
import { usePathname } from "next/navigation";
import * as React from "react";
import { Menu, ShoppingBag, X, Mountain } from "lucide-react";
import { cn } from "@/lib/utils";
import { useCart } from "@/lib/cart";
import { Button } from "./ui/button";

const links = [
  { href: "/menu", label: "Menu" }, { href: "/story", label: "Our Story" }, { href: "/gallery", label: "Gallery" },
  { href: "/visit", label: "Visit Us" }, { href: "/contact", label: "Contact" },
];

export function SiteHeader() {
  const path = usePathname();
  const { count } = useCart();
  const [open, setOpen] = React.useState(false);
  React.useEffect(() => setOpen(false), [path]);
  return (
    <header className="sticky top-0 z-40 border-b border-espresso/10 bg-cream/90 backdrop-blur">
      <div className="mx-auto flex h-16 max-w-7xl items-center justify-between px-5 md:px-8">
        <Link href="/" className="flex items-center gap-2.5">
          <span className="grid size-9 place-items-center rounded-full bg-espresso text-gold-soft"><Mountain className="size-4" aria-hidden /></span>
          <span className="font-display text-xl font-semibold tracking-tight">Yilhung Cafe</span>
        </Link>
        <nav aria-label="Primary" className="hidden items-center gap-7 lg:flex">
          {links.map((l) => (
            <Link key={l.href} href={l.href} aria-current={path === l.href ? "page" : undefined}
              className={cn("py-2 text-sm font-medium text-roast hover:text-terracotta", path === l.href && "text-terracotta underline decoration-gold decoration-2 underline-offset-8")}>{l.label}</Link>
          ))}
        </nav>
        <div className="flex items-center gap-2">
          <Button asChild variant="terracotta" size="sm" className="hidden sm:inline-flex">
            <Link href="/order">Order (demo){count > 0 && <span className="ml-1 rounded-full bg-paper/25 px-2 text-xs">{count}</span>}</Link>
          </Button>
          <Link href="/order" aria-label={`Cart, ${count} items`} className="relative grid size-11 place-items-center rounded-full hover:bg-espresso/5 sm:hidden">
            <ShoppingBag className="size-5" />{count > 0 && <span className="absolute right-1 top-1 grid size-5 place-items-center rounded-full bg-terracotta text-[11px] font-bold text-paper">{count}</span>}
          </Link>
          <Button variant="ghost" size="icon" className="lg:hidden" aria-expanded={open} aria-controls="mobile-nav" aria-label={open ? "Close menu" : "Open menu"} onClick={() => setOpen((o) => !o)}>
            {open ? <X /> : <Menu />}
          </Button>
        </div>
      </div>
      {open && (
        <nav id="mobile-nav" aria-label="Mobile" className="border-t border-espresso/10 bg-cream px-5 pb-5 lg:hidden">
          {[...links, { href: "/order", label: "Order (demo)" }].map((l) => (
            <Link key={l.href} href={l.href} className="flex min-h-12 items-center border-b border-espresso/10 font-display text-xl">{l.label}</Link>
          ))}
        </nav>
      )}
    </header>
  );
}
