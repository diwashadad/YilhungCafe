import * as React from "react";
import { Slot } from "@radix-ui/react-slot";
import { cva, type VariantProps } from "class-variance-authority";
import { cn } from "@/lib/utils";

const buttonVariants = cva(
  "inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-full text-sm font-semibold transition-colors disabled:pointer-events-none disabled:opacity-50 min-h-11 cursor-pointer",
  {
    variants: {
      variant: {
        default: "bg-espresso text-cream hover:bg-roast",
        terracotta: "bg-terracotta text-paper hover:bg-terracotta-deep",
        gold: "bg-gold-soft text-espresso hover:bg-gold hover:text-paper",
        outline: "border border-espresso/30 bg-transparent text-espresso hover:bg-espresso/5",
        ghost: "text-espresso hover:bg-espresso/5",
      },
      size: { default: "px-6 py-2.5", sm: "px-4 py-2 text-sm", icon: "size-11" },
    },
    defaultVariants: { variant: "default", size: "default" },
  }
);

export interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement>, VariantProps<typeof buttonVariants> { asChild?: boolean }

export const Button = React.forwardRef<HTMLButtonElement, ButtonProps>(({ className, variant, size, asChild, ...props }, ref) => {
  const Comp = asChild ? Slot : "button";
  return <Comp ref={ref} className={cn(buttonVariants({ variant, size }), className)} {...props} />;
});
Button.displayName = "Button";
export { buttonVariants };
