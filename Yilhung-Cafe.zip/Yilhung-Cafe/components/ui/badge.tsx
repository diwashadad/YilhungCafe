import { cn } from "@/lib/utils";
export function Badge({ className, ...p }: React.HTMLAttributes<HTMLSpanElement>) {
  return <span className={cn("inline-flex items-center rounded-full bg-gold-soft/60 px-3 py-1 text-xs font-semibold text-roast", className)} {...p} />;
}
