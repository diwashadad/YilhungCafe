"use client";
import * as React from "react";
import * as LabelPrimitive from "@radix-ui/react-label";
import { cn } from "@/lib/utils";
export const Label = React.forwardRef<React.ElementRef<typeof LabelPrimitive.Root>, React.ComponentPropsWithoutRef<typeof LabelPrimitive.Root>>(
  ({ className, ...p }, ref) => <LabelPrimitive.Root ref={ref} className={cn("text-sm font-semibold text-roast", className)} {...p} />
);
Label.displayName = "Label";
