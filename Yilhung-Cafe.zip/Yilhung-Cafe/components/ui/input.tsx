import * as React from "react";
import { cn } from "@/lib/utils";
const base = "w-full rounded-xl border border-espresso/25 bg-paper px-4 py-3 text-base text-espresso placeholder:text-espresso/50 focus-visible:border-terracotta";
export const Input = React.forwardRef<HTMLInputElement, React.InputHTMLAttributes<HTMLInputElement>>(({ className, ...p }, ref) => (
  <input ref={ref} className={cn(base, "min-h-11", className)} {...p} />
));
Input.displayName = "Input";
export const Textarea = React.forwardRef<HTMLTextAreaElement, React.TextareaHTMLAttributes<HTMLTextAreaElement>>(({ className, ...p }, ref) => (
  <textarea ref={ref} className={cn(base, "min-h-32", className)} {...p} />
));
Textarea.displayName = "Textarea";
