import { disclaimer } from "@/data/business-data";
export function DisclaimerBar() {
  return <div className="bg-espresso px-4 py-2 text-center text-xs font-medium text-gold-soft sm:text-sm">{disclaimer}</div>;
}
