import Image from "next/image";
import { cn } from "@/lib/utils";
import { Ridge } from "./himalayan";

type Props = {
  src?: string; alt: string; attribution?: string; label?: string; className?: string; priority?: boolean;
  tone?: "dark" | "terracotta" | "gold";
};
const tones = {
  dark: "from-roast via-espresso to-espresso",
  terracotta: "from-terracotta via-terracotta-deep to-roast",
  gold: "from-gold via-gold to-roast",
};

/**
 * Shows an authorized photo when `src` is provided; otherwise a clearly labeled placeholder.
 * We never use another café's photos as stand-ins (see docs/IMAGE-SOURCES.md).
 */
export function PhotoSlot({ src, alt, attribution, label = "Photo placeholder", className, priority, tone = "dark" }: Props) {
  if (src) {
    return (
      <figure className={cn("relative overflow-hidden", className)}>
        <Image src={src} alt={alt} fill sizes="(min-width:1024px) 50vw, 100vw" priority={priority} className="object-cover" />
        {attribution && <figcaption className="absolute bottom-2 right-2 rounded bg-espresso/70 px-2 py-1 text-[11px] text-cream">{attribution}</figcaption>}
      </figure>
    );
  }
  return (
    <div role="img" aria-label={`${alt} (placeholder, no photo yet)`} className={cn("weave relative overflow-hidden bg-linear-to-br", tones[tone], className)}>
      <div className="absolute inset-x-0 bottom-0 opacity-40"><Ridge fill="var(--color-cream)" /></div>
      <div className="absolute inset-x-0 bottom-0 opacity-30"><Ridge fill="var(--color-gold)" className="translate-y-3" /></div>
      {label && <span className="absolute left-3 top-3 rounded-full bg-cream/90 px-3 py-1 text-xs font-semibold text-roast">{label}: awaiting authorized Yilhung Cafe photo</span>}
    </div>
  );
}
