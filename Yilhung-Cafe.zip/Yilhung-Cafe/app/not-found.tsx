import Link from "next/link";
export default function NotFound() {
  return <div className="mx-auto max-w-xl px-5 py-32 text-center"><h1 className="text-5xl font-medium">Page not found</h1><p className="mt-3 text-roast">That page doesn’t exist in this demo.</p><Link className="mt-6 inline-block underline" href="/">Back home</Link></div>;
}
