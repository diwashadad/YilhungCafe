import type { Metadata } from "next";
import { MenuBrowser } from "@/components/menu-browser";
import { MENU_SOURCE_NOTE } from "@/data/menu";
import { TextileBand } from "@/components/art";
export const metadata: Metadata = { title: "Menu", description: "Himalayan butter tea, boba milk tea, lattes, passion fruit refreshers, chatpat and liangfen at Yilhung Cafe." };
export default function MenuPage() {
  return (
    <>
    <TextileBand className="block" />
    <div className="mx-auto max-w-7xl px-5 py-14 md:px-8 md:py-20">
      <h1 className="text-5xl font-medium md:text-7xl">Menu</h1>
      <p className="mt-3 max-w-2xl text-roast/85">{MENU_SOURCE_NOTE} Please confirm current items and prices with the café.</p>
      <div className="mt-10"><MenuBrowser /></div>
    </div>
    </>
  );
}
