import type { Metadata } from "next";
import { business, UNVERIFIED_NOTE } from "@/data/business-data";
import { ContactForm } from "@/components/contact-form";
import { FlagStripe } from "@/components/himalayan";
export const metadata: Metadata = { title: "Contact", description: "Contact Yilhung Cafe (unofficial concept demo)." };
export default function Contact() {
  return (
    <div className="mx-auto grid max-w-6xl gap-12 px-5 py-14 md:grid-cols-[1fr_1.2fr] md:px-8 md:py-20">
      <div>
        <FlagStripe className="mb-6 w-24" />
        <h1 className="text-5xl font-medium md:text-6xl">Say hello</h1>
        <p className="mt-4 text-roast">Questions about the menu, the café, or this concept? Send a note.</p>
        <dl className="mt-8 space-y-4 text-roast">
          <div><dt className="font-semibold">Address</dt><dd>{business.address.value.display}</dd></div>
          <div><dt className="font-semibold">Phone</dt><dd>{business.phone ? `${business.phone.value} (from the café’s printed menu; please confirm)` : `To be confirmed. ${UNVERIFIED_NOTE}`}</dd></div>
        </dl>
        <p className="mt-8 rounded-2xl border border-gold/50 bg-paper p-4 text-sm">This is an unofficial concept. Messages go to the agency’s configured destination, not to Yilhung Cafe, unless the owner arranges otherwise.</p>
      </div>
      <ContactForm />
    </div>
  );
}
