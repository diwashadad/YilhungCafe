import Link from "next/link";
import { ArrowUpRight, Gem } from "lucide-react";
import { menu } from "@/data/menu";
import { business, DIRECTIONS_URL } from "@/data/business-data";
import { Button } from "@/components/ui/button";
import { Hero } from "@/components/hero";
import { Ridge } from "@/components/himalayan";
import { MenuCard } from "@/components/menu-card";
import { Reveal } from "@/components/reveal";
import { Illustration } from "@/components/illustration";
import { ButterTeaArt, ChatpatArt, CraftsArt, MomoArt, TextileBand } from "@/components/art";

const ribbon = ["Himalayan butter tea", "Boba milk tea", "Fruit tea", "Lassi", "Lattes", "Momo", "Chatpate", "Laphing", "Liangfen"];

export default function Home() {
  const signature = menu.filter((m) => m.signature);
  return (
    <>
      <Hero />

      {/* Offerings ribbon */}
      <div className="mt-6 overflow-hidden border-y border-espresso/15 bg-paper py-4" aria-label="What we serve">
        <div className="marquee flex w-max gap-10 whitespace-nowrap font-display text-2xl text-roast md:text-3xl" aria-hidden>
          {[...ribbon, ...ribbon, ...ribbon, ...ribbon].map((r, i) => (<span key={i} className="flex items-center gap-10">{r}<span className="size-2 rotate-45 bg-gold" /></span>))}
        </div>
        <p className="sr-only">{ribbon.join(", ")}</p>
      </div>

      {/* Signature */}
      <section className="mx-auto max-w-7xl px-5 pt-24 md:px-8">
        <Reveal className="flex flex-wrap items-end justify-between gap-4">
          <div>
            <h2 className="max-w-xl text-4xl font-medium leading-tight md:text-6xl">What we’re known for</h2>
            <p className="mt-3 max-w-lg text-roast/85">The drinks and snacks that put Yilhung Cafe on the Queens map.</p>
          </div>
          <Button asChild variant="outline" className="hidden sm:inline-flex"><Link href="/menu">Full menu <ArrowUpRight className="size-4" aria-hidden /></Link></Button>
        </Reveal>
        <div className="-mx-5 mt-10 flex snap-x snap-mandatory gap-4 overflow-x-auto px-5 pb-4 [scrollbar-width:none] md:mx-0 md:grid md:grid-cols-2 md:overflow-visible md:px-0 lg:grid-cols-4">
          {signature.map((m, i) => (
            <Reveal key={m.id} delay={i * 0.07} className="w-[78%] shrink-0 snap-center sm:w-[46%] md:w-auto"><MenuCard item={m} /></Reveal>
          ))}
        </div>
        <Button asChild variant="outline" className="mt-4 sm:hidden"><Link href="/menu">Full menu <ArrowUpRight className="size-4" aria-hidden /></Link></Button>
      </section>

      {/* Butter tea feature */}
      <section className="relative mt-28 bg-espresso text-cream">
        <Ridge fill="var(--color-cream)" flip className="-mt-px" />
        <div className="mx-auto grid max-w-7xl items-center gap-12 px-5 pb-24 pt-8 md:grid-cols-2 md:px-8">
          <Reveal>
            <Illustration className="mx-auto aspect-square w-full max-w-md rounded-full bg-linear-to-b from-terracotta to-terracotta-deep p-12 shadow-[0_40px_80px_-30px_rgb(0_0_0/.6)] ring-8 ring-gold/25">
              <div className="bob size-full"><ButterTeaArt animated /></div>
            </Illustration>
          </Reveal>
          <Reveal delay={0.1}>
            <h2 className="text-4xl font-medium leading-tight md:text-6xl">Himalayan butter tea</h2>
            <p className="mt-5 max-w-md text-lg leading-relaxed text-cream/85">Salty and rich, it’s the drink that sets Yilhung Cafe apart from the usual café menu.</p>
            <p className="mt-4 max-w-md text-sm leading-relaxed text-cream/65">About the drink: butter tea is a traditional beverage of the Himalayan region, made from tea, butter and salt.</p>
            <div className="mt-8 flex flex-wrap gap-3">
              <Button asChild variant="gold"><Link href="/order?item=butter-tea">Try it in the demo</Link></Button>
              <Button asChild variant="outline" className="border-cream/40 text-cream hover:bg-cream/10"><Link href="/menu">See the menu</Link></Button>
            </div>
          </Reveal>
        </div>
      </section>

      {/* Snacks */}
      <section className="mx-auto max-w-7xl px-5 pt-24 md:px-8">
        <Reveal><h2 className="max-w-xl text-4xl font-medium leading-tight md:text-6xl">Street snacks and dumplings to go with your cup</h2></Reveal>
        <div className="mt-10 grid gap-5 md:grid-cols-2">
          {[{ id: "chatpat", art: <ChatpatArt />, bg: "bg-[#c9d3d9]", name: "Chatpate", note: "A tangy, savory South Asian street-style snack." },
            { id: "momo-beef", art: <MomoArt />, bg: "bg-[#dcc6a6]", name: "Momo", note: "Dumplings, with beef or vegetable fillings." }].map((s, i) => (
            <Reveal key={s.id} delay={i * 0.08}>
              <Link href={`/order?item=${s.id}`} className="group flex items-center gap-5 rounded-[2rem] border border-espresso/10 bg-paper p-4 pr-6 transition-colors hover:border-terracotta/50 sm:gap-7">
                <Illustration className={`aspect-square w-36 shrink-0 rounded-[1.5rem] sm:w-48 ${s.bg}`}><div className="size-full p-3 transition-transform duration-500 group-hover:scale-110">{s.art}</div></Illustration>
                <div><h3 className="text-2xl font-medium">{s.name}</h3><p className="mt-1 text-sm text-roast/85">{s.note}</p><span className="mt-3 inline-flex items-center gap-1 text-sm font-semibold text-terracotta">Try in demo <ArrowUpRight className="size-4" aria-hidden /></span></div>
              </Link>
            </Reveal>
          ))}
        </div>
      </section>

      {/* Crafts corner */}
      <section className="mt-28">
        <TextileBand className="block" />
        <div className="bg-roast text-cream">
          <div className="mx-auto grid max-w-7xl items-center gap-12 px-5 py-20 md:grid-cols-2 md:px-8">
            <Reveal>
              <h2 className="text-4xl font-medium leading-tight md:text-6xl">A corner of Himalayan crafts</h2>
              <p className="mt-5 max-w-md text-lg leading-relaxed text-cream/85">Yilhung Cafe pairs a warm, stylish atmosphere with a corner dedicated to Himalayan artifacts and crafts.</p>
              <ul className="mt-6 space-y-3 text-cream/90"><li className="flex gap-3"><Gem className="mt-0.5 size-5 shrink-0 text-gold" aria-hidden /> Himalayan artifacts and crafts on display</li></ul>
              <Button asChild variant="gold" className="mt-8"><Link href="/story">Our story</Link></Button>
            </Reveal>
            <Reveal delay={0.1}><Illustration className="aspect-[4/3] rounded-[2rem] shadow-[0_40px_80px_-40px_rgb(0_0_0/.7)]"><CraftsArt /></Illustration></Reveal>
          </div>
        </div>
        <TextileBand className="block" />
      </section>

      {/* Visit + order */}
      <section className="mx-auto grid max-w-7xl gap-5 px-5 pt-24 md:grid-cols-2 md:px-8">
        <Reveal className="rounded-[2rem] border border-espresso/10 bg-paper p-8 md:p-10">
          <h2 className="text-3xl font-medium md:text-4xl">Find us</h2>
          <p className="mt-3 text-lg text-roast">{business.address.value.display}</p>
          <p className="mt-1 text-sm text-roast/70">Opening hours: to be confirmed. Check Google Maps for today’s hours.</p>
          <div className="mt-6 flex flex-wrap gap-3">
            <Button asChild variant="terracotta"><a href={DIRECTIONS_URL} target="_blank" rel="noopener noreferrer">Get directions</a></Button>
            <Button asChild variant="outline"><Link href="/visit">Visit details</Link></Button>
          </div>
        </Reveal>
        <Reveal delay={0.08} className="rounded-[2rem] bg-terracotta p-8 text-paper md:p-10">
          <h2 className="text-3xl font-medium md:text-4xl">Try the pickup flow</h2>
          <p className="mt-3 max-w-sm text-paper/90">See how online ordering could feel: customize a drink, add snacks, check out. It’s a demo, so no orders are placed and no payment is taken.</p>
          <Button asChild variant="gold" className="mt-6"><Link href="/order">Open the ordering demo</Link></Button>
        </Reveal>
      </section>
    </>
  );
}
