import type { Metadata } from "next";
import { Clock, MapPin, Phone, CreditCard } from "lucide-react";
import { business, DIRECTIONS_URL, MAPS_EMBED_URL, MAPS_URL, UNVERIFIED_NOTE } from "@/data/business-data";
import { Button } from "@/components/ui/button";
import { FlagStripe } from "@/components/himalayan";
export const metadata: Metadata = { title: "Visit Us", description: "Address, map and directions for Yilhung Cafe, 40-36 75th St, Elmhurst, NY 11373." };
export default function Visit() {
  const rows = [
    { icon: MapPin, title: "Address", body: business.address.value.display },
    { icon: Clock, title: "Hours", body: business.hours ? business.hours.value.map((h) => `${h.day}: ${h.open}`).join(" · ") : `Hours to be confirmed. ${UNVERIFIED_NOTE}` },
    { icon: Phone, title: "Phone", body: business.phone ? `${business.phone.value} (from the café’s printed menu; please confirm)` : `Phone to be confirmed. ${UNVERIFIED_NOTE}` },
    { icon: CreditCard, title: "Payment", body: business.payments.value },
  ];
  return (
    <div className="mx-auto max-w-7xl px-5 py-14 md:px-8 md:py-20">
      <FlagStripe className="mb-6 w-24" />
      <h1 className="text-5xl font-medium md:text-6xl">Visit us</h1>
      <div className="mt-10 grid gap-8 lg:grid-cols-[1fr_1.3fr]">
        <div className="space-y-5">
          {rows.map(({ icon: I, title, body }) => (
            <div key={title} className="flex gap-4 rounded-2xl border border-espresso/10 bg-paper p-5">
              <I className="mt-1 size-5 shrink-0 text-terracotta" aria-hidden />
              <div><h2 className="font-sans text-base font-semibold">{title}</h2><p className="mt-1 text-roast">{body}</p></div>
            </div>
          ))}
          <div className="flex flex-wrap gap-3">
            <Button asChild variant="terracotta"><a href={DIRECTIONS_URL} target="_blank" rel="noopener noreferrer">Get directions</a></Button>
            <Button asChild variant="outline"><a href={MAPS_URL} target="_blank" rel="noopener noreferrer">Open in Google Maps</a></Button>
          </div>
        </div>
        <div className="min-h-96 overflow-hidden rounded-3xl border border-espresso/10">
          <iframe title="Map showing Yilhung Cafe, 40-36 75th St, Elmhurst NY" src={MAPS_EMBED_URL} loading="lazy" referrerPolicy="no-referrer-when-downgrade" className="h-full min-h-96 w-full" />
        </div>
      </div>
    </div>
  );
}
