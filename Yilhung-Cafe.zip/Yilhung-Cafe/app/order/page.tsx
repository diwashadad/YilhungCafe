import type { Metadata } from "next";
import { Suspense } from "react";
import { OrderDemo } from "@/components/order-demo";
import { FlagStripe } from "@/components/himalayan";
export const metadata: Metadata = { title: "Online Ordering Demo", description: "Interactive demo of an online ordering flow. No real orders or payments." };
export default function Order() {
  return (
    <div className="mx-auto max-w-7xl px-5 py-14 md:px-8 md:py-20">
      <FlagStripe className="mb-6 w-24" />
      <h1 className="text-5xl font-medium md:text-6xl">Order online <span className="align-middle font-sans text-base font-bold text-terracotta">(demo)</span></h1>
      <p className="mt-3 max-w-2xl rounded-2xl border border-terracotta/40 bg-paper p-4 text-roast"><strong>Demo only.</strong> This shows how online pickup ordering could work. It does not place real orders or take payments, and all prices are placeholders.</p>
      <div className="mt-10"><Suspense><OrderDemo /></Suspense></div>
    </div>
  );
}
