import type { Metadata, Viewport } from "next";
import { Fraunces, Hanken_Grotesk } from "next/font/google";
import "./globals.css";
import { CartProvider } from "@/lib/cart";
import { DisclaimerBar } from "@/components/disclaimer-bar";
import { SiteHeader } from "@/components/site-header";
import { SiteFooter } from "@/components/site-footer";
import { business } from "@/data/business-data";

const fraunces = Fraunces({ subsets: ["latin"], variable: "--font-fraunces", display: "swap" });
const hanken = Hanken_Grotesk({ subsets: ["latin"], variable: "--font-hanken", display: "swap" });

const desc = `Unofficial redesign concept for ${business.name.value}, ${business.address.value.display}: Himalayan butter tea, boba milk tea, lattes, passion fruit refreshers, chatpat and liangfen.`;
export const metadata: Metadata = {
  title: { default: "Yilhung Cafe — Unofficial redesign concept", template: "%s · Yilhung Cafe (unofficial concept)" },
  description: desc,
  robots: { index: false, follow: false }, // private demo until owner approves publishing
  openGraph: { title: "Yilhung Cafe — Unofficial redesign concept", description: desc, type: "website", locale: "en_US" },
};
export const viewport: Viewport = { themeColor: "#2b1d16", width: "device-width", initialScale: 1 };

const jsonLd = {
  "@context": "https://schema.org", "@type": "CafeOrCoffeeShop", name: business.name.value,
  address: { "@type": "PostalAddress", streetAddress: business.address.value.street, addressLocality: "Elmhurst", addressRegion: "NY", postalCode: "11373", addressCountry: "US" },
  hasMap: business.mapsUrl.value, servesCuisine: ["Himalayan", "Tea", "Coffee"],
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" className={`${fraunces.variable} ${hanken.variable}`}>
      <body>
        <a href="#main" className="sr-only focus:not-sr-only focus:fixed focus:left-3 focus:top-3 focus:z-50 focus:rounded-full focus:bg-paper focus:px-4 focus:py-2">Skip to content</a>
        <CartProvider>
          <DisclaimerBar />
          <SiteHeader />
          <main id="main">{children}</main>
          <SiteFooter />
        </CartProvider>
        <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }} />
      </body>
    </html>
  );
}
