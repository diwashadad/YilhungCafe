import type { Metadata } from "next";
import { Camera } from "lucide-react";
import { Illustration } from "@/components/illustration";
import { PhotoSlot } from "@/components/photo-slot";
import { BobaArt, ButterTeaArt, ChatpatArt, CraftsArt, LatteArt, LiangfenArt, MomoArt, PassionFruitArt } from "@/components/art";
import { Reveal } from "@/components/reveal";
export const metadata: Metadata = { title: "Gallery", description: "Gallery for Yilhung Cafe: authorized photos coming soon, plus illustrated moods." };

/** AUTHORIZED real photos of Yilhung Cafe go here. See docs/IMAGE-SOURCES.md. Empty until permission/licence is confirmed. */
const realPhotos: { src: string; alt: string; attribution: string }[] = [];

const moods = [
  { name: "Butter tea", art: <ButterTeaArt animated />, bg: "bg-[#e9d3a8]", span: "md:col-span-2 md:row-span-2" },
  { name: "Boba milk tea", art: <BobaArt />, bg: "bg-[#e8cdb8]" },
  { name: "Latte", art: <LatteArt />, bg: "bg-[#d9c3a5]" },
  { name: "Himalayan crafts corner", art: <CraftsArt />, bg: "bg-roast", span: "md:col-span-2", full: true },
  { name: "Passion fruit refresher", art: <PassionFruitArt />, bg: "bg-[#f1dca6]" },
  { name: "Chatpat", art: <ChatpatArt />, bg: "bg-[#c9d3d9]" },
  { name: "Momo", art: <MomoArt />, bg: "bg-[#dcc6a6]" },
  { name: "Liangfen", art: <LiangfenArt />, bg: "bg-[#ecd2c3]" },
];

export default function Gallery() {
  return (
    <div className="mx-auto max-w-7xl px-5 py-16 md:px-8 md:py-24">
      <h1 className="text-5xl font-medium md:text-7xl">Gallery</h1>

      <section aria-labelledby="real" className="mt-12">
        <h2 id="real" className="text-2xl font-medium">Photos of Yilhung Cafe</h2>
        {realPhotos.length ? (
          <div className="mt-5 grid auto-rows-[16rem] gap-4 md:grid-cols-3">{realPhotos.map((p) => <PhotoSlot key={p.src} {...p} className="rounded-3xl" />)}</div>
        ) : (
          <div className="mt-5 flex items-start gap-4 rounded-3xl border border-dashed border-espresso/30 bg-paper p-6 md:items-center">
            <Camera className="size-7 shrink-0 text-terracotta" aria-hidden />
            <p className="max-w-2xl text-roast">Real photos of the café will appear here, with credit, once the owner gives permission or they’re available through an authorized source. Everything below is <strong>illustration</strong>, not a photograph of Yilhung Cafe.</p>
          </div>
        )}
      </section>

      <section aria-labelledby="moods" className="mt-16">
        <h2 id="moods" className="text-2xl font-medium">Illustrated moods</h2>
        <div className="mt-5 grid auto-rows-[15rem] grid-cols-2 gap-4 md:grid-cols-4">
          {moods.map((m, i) => (
            <Reveal key={m.name} delay={(i % 4) * 0.05} className={`${m.span ?? ""} ${m.name === "Himalayan crafts corner" ? "col-span-2" : ""}`}>
              <Illustration className={`h-full rounded-[1.75rem] ${m.bg}`}>
                {m.full ? <div className="size-full">{m.art}</div> : <div className="grid size-full place-items-center p-6"><div className="size-full max-w-64">{m.art}</div></div>}
                <span className="absolute right-3 top-3 rounded-full bg-paper/90 px-3 py-1 text-xs font-semibold text-roast">{m.name}</span>
              </Illustration>
            </Reveal>
          ))}
        </div>
      </section>
    </div>
  );
}
