export const dynamic = "force-static";
import type { MetadataRoute } from "next";
// Intentionally empty while the demo is private/noindex.
export default function sitemap(): MetadataRoute.Sitemap { return []; }
