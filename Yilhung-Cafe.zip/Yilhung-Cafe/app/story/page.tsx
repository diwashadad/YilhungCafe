import type { Metadata } from "next";
import { business } from "@/data/business-data";
import { Illustration } from "@/components/illustration";
import { CraftsArt, TextileBand } from "@/components/art";
import { Reveal } from "@/components/reveal";
export const metadata: Metadata = { title: "Our Story", description: "About Yilhung Cafe in Queens: Himalayan butter tea, boba, lattes and a corner of Himalayan crafts." };
export default function Story() {
  return (
    <>
      <TextileBand className="block" />
      <div className="mx-auto max-w-6xl px-5 py-16 md:px-8 md:py-24">
        <h1 className="max-w-3xl text-5xl font-medium leading-[1.05] md:text-7xl">A café with the Himalayas in the corner</h1>
        <div className="mt-14 grid items-start gap-12 md:grid-cols-[1.1fr_1fr]">
          <Reveal className="space-y-6 text-lg leading-[1.75] text-roast">
            <p>Yilhung Cafe is a café at {business.address.value.display}.</p>
            <p>The menu mixes familiar café drinks with Himalayan flavors: lattes and boba milk tea beside passion fruit refreshers and a salty, rich butter tea, plus street snacks like chatpat and liangfen.</p>
            <p>The atmosphere is warm and stylish, with a corner dedicated to Himalayan artifacts and crafts.</p>
            <p className="rounded-2xl border border-gold/50 bg-paper p-5 text-base leading-relaxed">
              <strong>A note on this page:</strong> we publish only facts we could verify. The café’s founding story, owners and history are <em>to be confirmed</em> and will be added once the café provides them.
            </p>
          </Reveal>
          <Reveal delay={0.1}><Illustration className="aspect-[4/5] rounded-[2rem] shadow-[0_40px_80px_-40px_rgb(43_29_22/.6)]"><CraftsArt /></Illustration></Reveal>
        </div>
      </div>
    </>
  );
}
