import type { NextConfig } from "next";
// Static export: the site is served by a Cloudflare Worker with static assets (see wrangler.jsonc).
// Response headers (incl. the demo's noindex) live in public/_headers.
const nextConfig: NextConfig = {
  output: "export",
  images: { unoptimized: true },
};
export default nextConfig;
