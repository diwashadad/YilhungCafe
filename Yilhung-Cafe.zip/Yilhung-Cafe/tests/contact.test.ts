import { test } from "node:test";
import assert from "node:assert/strict";
import { validateContact } from "../lib/contact.ts";
test("rejects bad input", () => {
  const r = validateContact({ name: "A", email: "x", message: "hi" });
  assert.equal(r.ok, false);
  if (!r.ok) assert.deepEqual(Object.keys(r.errors).sort(), ["email", "message", "name"]);
});
test("accepts good input", () => assert.equal(validateContact({ name: "Sam", email: "sam@example.com", message: "Hello there, friend" }).ok, true));
