// Run: npm run build && npx next start -p 3100 & ; node tests/e2e.mjs
import { chromium } from "playwright";
import assert from "node:assert/strict";
const base = process.env.BASE ?? "http://localhost:3100";
const b = await chromium.launch(process.env.CHROMIUM ? { executablePath: process.env.CHROMIUM, args: ["--no-sandbox"] } : {}); 
const bad = [];
for (const [name, vp] of [["desktop", { width: 1280, height: 800 }], ["mobile", { width: 390, height: 844 }]]) {
  const ctx = await b.newContext({ viewport: vp }); const p = await ctx.newPage();
  p.on("pageerror", (e) => bad.push(`${name} pageerror ${e.message}`));
  p.on("console", (m) => m.type() === "error" && !/Failed to load resource|maps/.test(m.text()) && bad.push(`${name} console ${m.text()}`));
  for (const path of ["/", "/menu", "/story", "/gallery", "/visit", "/contact", "/order"]) {
    const r = await p.goto(base + path); assert.equal(r.status(), 200, path);
    assert.ok(await p.getByText("Unofficial redesign concept — not affiliated with Yilhung Cafe.").first().isVisible(), `disclaimer ${path}`);
    const over = await p.evaluate(() => document.documentElement.scrollWidth - window.innerWidth);
    assert.ok(over <= 1, `${name} horizontal overflow ${over}px on ${path}`);
    await p.evaluate(async () => { for (let y = 0; y < document.body.scrollHeight; y += 400) { window.scrollTo(0, y); await new Promise(r => setTimeout(r, 250)); } window.scrollTo(0, 0); });
    await p.screenshot({ path: `tests/shots/${name}${path === "/" ? "-home" : path.replace("/", "-")}.png`, fullPage: true });
  }
  // menu search + filter
  await p.goto(base + "/menu");
  await p.getByLabel("Search the menu").fill("boba");
  await p.waitForFunction(() => document.querySelectorAll("article").length === 1);
  await p.getByLabel("Search the menu").fill("zzzz"); assert.ok(await p.getByText("Nothing matches").isVisible());
  await p.getByLabel("Search the menu").fill(""); await p.getByRole("button", { name: "Food & Snacks" }).click();
  await p.waitForFunction(() => document.querySelectorAll("article").length === 9);
  // cart flow
  await p.goto(base + "/order");
  await p.getByRole("button", { name: "Customize and add Boba Milk Tea" }).click();
  await p.locator("label", { hasText: "Boba pearls" }).click(); await p.locator("label", { hasText: "Large" }).click();
  await p.getByRole("button", { name: /Add to demo order/ }).click();
  assert.ok(await p.getByText("$7.75").first().isVisible()); // 6 + 1 + .75
  await p.getByRole("button", { name: "Increase quantity of Boba Milk Tea" }).last().click();
  assert.ok(await p.getByText("$15.50").first().isVisible());
  await p.getByRole("button", { name: "Place demo order" }).click(); assert.ok(await p.getByText("Please enter a name").isVisible());
  await p.getByLabel("Pickup name").fill("Test"); await p.getByRole("button", { name: "Place demo order" }).click();
  assert.ok(await p.getByText("DEMO ONLY: NO ORDER WAS PLACED").isVisible());
  // contact form
  await p.goto(base + "/contact");
  await p.getByRole("button", { name: "Send message" }).click(); await p.getByText("Please enter a valid email").waitFor({ timeout: 5000 });
  await p.getByLabel("Name").fill("Sam"); await p.getByLabel("Email").fill("sam@example.com"); await p.getByLabel("Message").fill("Hello, a test message.");
  await p.getByRole("button", { name: "Send message" }).click(); await p.getByText("Demo mode").waitFor({ timeout: 5000 });
  // mobile nav
  if (name === "mobile") { await p.goto(base); await p.getByRole("button", { name: "Open menu" }).click(); await p.getByRole("navigation", { name: "Mobile" }).getByRole("link", { name: "Visit Us" }).click(); await p.waitForURL("**/visit"); }
  await ctx.close();
}
await b.close();
if (bad.length) { console.error(bad); process.exit(1); }
console.log("E2E OK");
