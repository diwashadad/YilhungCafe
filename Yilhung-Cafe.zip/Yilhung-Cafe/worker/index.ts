import { validateContact } from "../lib/contact";

interface Env {
  ASSETS: Fetcher;
  CONTACT_WEBHOOK_URL?: string;
  RESEND_API_KEY?: string;
  CONTACT_TO_EMAIL?: string;
  CONTACT_FROM_EMAIL?: string;
}
const json = (body: unknown, status = 200) => new Response(JSON.stringify(body), { status, headers: { "content-type": "application/json", "cache-control": "no-store" } });

async function contact(req: Request, env: Env): Promise<Response> {
  let body: unknown;
  try { body = await req.json(); } catch { return json({ ok: false, errors: { form: "Invalid request." } }, 400); }
  const v = validateContact(body);
  if (!v.ok) return json(v, 422);
  if (v.data.website) return json({ ok: true, mode: "ignored" }); // honeypot
  const { name, email, message } = v.data;
  try {
    if (env.CONTACT_WEBHOOK_URL) {
      const r = await fetch(env.CONTACT_WEBHOOK_URL, { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ text: `New message from ${name} <${email}>:\n${message}`, name, email, message }) });
      if (!r.ok) throw new Error(`webhook ${r.status}`);
      return json({ ok: true, mode: "webhook" });
    }
    if (env.RESEND_API_KEY && env.CONTACT_TO_EMAIL && env.CONTACT_FROM_EMAIL) {
      const r = await fetch("https://api.resend.com/emails", { method: "POST", headers: { authorization: `Bearer ${env.RESEND_API_KEY}`, "content-type": "application/json" },
        body: JSON.stringify({ from: env.CONTACT_FROM_EMAIL, to: env.CONTACT_TO_EMAIL, reply_to: email, subject: `Website message from ${name}`, text: `${message}\n\n— ${name} <${email}>` }) });
      if (!r.ok) throw new Error(`resend ${r.status}`);
      return json({ ok: true, mode: "email" });
    }
  } catch (e) {
    console.error("contact delivery failed", e);
    return json({ ok: false, errors: { form: "Sorry, we couldn't send that. Please try again later." } }, 502);
  }
  return json({ ok: true, mode: "demo" }); // no destination configured
}

export default {
  async fetch(req: Request, env: Env): Promise<Response> {
    const url = new URL(req.url);
    if (url.pathname === "/api/contact") return req.method === "POST" ? contact(req, env) : json({ ok: false, errors: { form: "Method not allowed." } }, 405);
    return env.ASSETS.fetch(req);
  },
};
